# Weer

Persoonlijke app voor realtime signalering van onweer, orkanen, aardbevingen,
tornado's, algemeen weer en de hemel (maanstand, satellieten, aurora,
meteorenzwermen). Geen educatie — puur actuele data.

Achtergrond, ontwerp en de volledige bron-inventarisatie staan in het
Claude-project **"Weer"** (`weer-app-architectuur-en-ontwerp.md` en
`weer-hoofdinventarisatie-datastromen.md`).

## Structuur

```
backend/    aggregator-service — pollt externe bronnen, normaliseert, cachet,
            serveert alles via één API + de frontend zelf
frontend/   de Storm Noir PWA-schil (vanilla HTML/CSS/JS, geen build-stap)
```

Bewust **geen** frameworks of dependencies nodig om te starten — dit is een
klein persoonlijk project, geen enterprise-app.

## Starten

```
cd backend
node src/index.js
```

Open daarna `http://localhost:4173` in je browser. Dat is alles — geen
`npm install` nodig, de backend gebruikt alleen Node's ingebouwde modules.

Wil je een eigen locatie of poort instellen? Kopieer `backend/.env.example`
naar `backend/.env` en pas de waarden aan.

## Wat werkt er al

- **Aardbevingen (USGS)** — echte koppeling, geen sleutel nodig.
- **Maanstand** — lokaal berekend, geen externe bron nodig.
- Alle overige bronnen uit de inventarisatie staan als stub klaar in
  `backend/src/sources/`, met een verwijzing naar de juiste documentatie en
  een `TODO` — zie hieronder hoe je er één afmaakt.

> **Let op:** in de cloud-sandbox waarin dit is gebouwd en getest, blokkeert
> het netwerkbeleid uitgaande verzoeken naar externe API's zoals
> `earthquake.usgs.gov`. De code zelf is correct (lokaal geverifieerd met de
> maanstand-berekening, die geen netwerk nodig heeft) — zodra je dit op je
> eigen PC/server draait met normale internettoegang, zou de USGS-koppeling
> gewoon data moeten teruggeven. Controleer dat als eerste stap.

## Een nieuwe bron aansluiten

1. Open `backend/src/sources/<naam>.js` — de TODO-comment verwijst naar de
   juiste documentatie-URL.
2. Implementeer de `fetchXxx()`-functie: haal data op, zet elk item om naar
   een signaal via `makeSignal({...})` uit `normalize.js`.
3. Zet `implemented: true` in `backend/src/config.js` bij die bron.
4. Klaar — polling, caching, de betrouwbaarheidsindicator en de API-routes
   werken automatisch mee, niets anders hoeft aangepast te worden.

## API

- `GET /api/status` — status per bron (bijgewerkt-tijdstip, betrouwbaarheidstier, haperend ja/nee)
- `GET /api/signals` — alle actuele signalen
- `GET /api/signals/:categorie` — bijv. `/api/signals/aardbeving`

## Op meerdere apparaten (Tailscale)

Zodra deze service draait op een machine in je tailnet, is 'm op je andere
apparaten (telefoon, tablet, andere pc) bereikbaar via de Tailscale-hostnaam
van die machine, op dezelfde poort (standaard 4173) — bijvoorbeeld
`http://<machinenaam>.<jouw-tailnet>.ts.net:4173`. Voeg de pagina op je
telefoon/tablet toe aan het beginscherm voor de volledige PWA-ervaring
(fullscreen, eigen icoon).

## Frontend

`frontend/index.html` + `app.js` + `styles.css` vormen de werkende versie van
de Storm Noir-mockups (ticker, kaart met pins, signaalstrip met
betrouwbaarheidsindicator, hemel-kaart). De losse ontwerp-mockups
(`weer-moodboard.html`, `weer-homescreen-storm-noir.html`,
`weer-responsive-layout.html`, `weer-inventarisatie.html`) staan als
referentie in het Claude-project, niet in deze repo.
