// Bronregister — één plek die overeenkomt met de hoofdinventarisatie
// (project: "Weer" > weer-hoofdinventarisatie-datastromen.md).
//
// tier: 'officieel' | 'community' | 'lokaal'
// Community-bronnen worden in de UI expliciet gemarkeerd en klappen om naar
// "haperend" als staleAfterMs verstreken is zonder succesvolle update.

export const SOURCES = [
  {
    id: 'usgs',
    categorie: 'aardbeving',
    naam: 'USGS Earthquake Feed',
    tier: 'officieel',
    pollIntervalMs: 90 * 1000,
    staleAfterMs: 10 * 60 * 1000,
    implemented: true,
  },
  {
    id: 'emsc',
    categorie: 'aardbeving',
    naam: 'EMSC SeismicPortal',
    tier: 'officieel',
    pollIntervalMs: 2 * 60 * 1000,
    staleAfterMs: 10 * 60 * 1000,
    implemented: true,
    note: 'FDSN REST-query (niet de WebSocket) — Europees-Mediterrane focus, kan overlappen met USGS.',
  },
  {
    id: 'nhc',
    categorie: 'orkaan',
    naam: 'NOAA National Hurricane Center',
    tier: 'officieel',
    pollIntervalMs: 45 * 60 * 1000,
    staleAfterMs: 3 * 60 * 60 * 1000,
    implemented: true,
    note: 'CurrentStorms.json op nhc.noaa.gov — geen officiële uptime-garantie',
  },
  {
    id: 'nws',
    categorie: 'tornado',
    naam: 'NWS api.weather.gov (alerts)',
    tier: 'officieel',
    pollIntervalMs: 2 * 60 * 1000,
    staleAfterMs: 30 * 60 * 1000,
    implemented: true,
    note: 'Vereist herkenbare User-Agent header. Dekt alleen de VS. Levert twee categorieën: tornado (Warning) en tornado-watch (Watch, incl. polygon-omtrek van het gebied).',
  },
  {
    id: 'spcOutlook',
    categorie: 'severe-outlook',
    naam: 'NOAA Storm Prediction Center (Day 1 Outlook)',
    tier: 'officieel',
    pollIntervalMs: 30 * 60 * 1000,
    staleAfterMs: 6 * 60 * 60 * 1000,
    implemented: true,
    note: 'Categorical Day 1-outlook, alleen Enhanced/Moderate/High-risicogebieden (Marginal/Slight bewust weggefilterd — te routinematig ergens in de VS). VS-only, incl. polygon-omtrek.',
  },
  {
    id: 'iemLsr',
    categorie: 'tornado-bevestigd',
    naam: 'IEM Local Storm Reports (bevestigde tornado\'s)',
    tier: 'officieel',
    pollIntervalMs: 3 * 60 * 1000,
    staleAfterMs: 20 * 60 * 1000,
    implemented: true,
    note: 'Spiegelt NWS Local Storm Reports, gefilterd op typetext=TORNADO — daadwerkelijk gemelde/bevestigde tornado\'s, geen voorspelling. Venster van 3 uur. VS-only.',
  },
  {
    id: 'openmeteo',
    categorie: 'algemeen-weer',
    naam: 'Open-Meteo',
    tier: 'officieel',
    pollIntervalMs: 15 * 60 * 1000,
    staleAfterMs: 2 * 60 * 60 * 1000,
    implemented: true,
    note: 'Gratis, geen sleutel nodig (niet-commercieel), tot 10.000 requests/dag.',
  },
  {
    id: 'knmi',
    categorie: 'algemeen-weer',
    naam: 'KNMI Open Data',
    tier: 'officieel',
    pollIntervalMs: 20 * 60 * 1000,
    staleAfterMs: 2 * 60 * 60 * 1000,
    implemented: false,
    note: 'Vereist gratis API-sleutel, zie developer.dataplatform.knmi.nl. Alternatief/aanvulling op Open-Meteo voor NL-specifieke precisie.',
  },
  {
    id: 'meteoalarm',
    categorie: 'weerwaarschuwing',
    naam: 'Meteoalarm',
    tier: 'officieel',
    pollIntervalMs: 20 * 60 * 1000,
    staleAfterMs: 2 * 60 * 60 * 1000,
    implemented: true,
    note: 'Legacy Atom+CAP-feed, regex-parser. Geen lat/lon, dus geen kaartpin — wel in Meldingen.',
  },
  {
    id: 'gdacs',
    categorie: 'multi-hazard',
    naam: 'GDACS',
    tier: 'officieel',
    pollIntervalMs: 3 * 60 * 60 * 1000,
    staleAfterMs: 12 * 60 * 60 * 1000,
    implemented: true,
    note: 'Vangnet-bron voor overstroming/natuurbrand/vulkaan/droogte en cyclonen buiten NHC. Alleen Orange/Red.',
  },
  {
    id: 'blitzortung',
    categorie: 'onweercomplex',
    naam: 'Blitzortung.org',
    tier: 'community',
    pollIntervalMs: null, // permanente WebSocket-stream i.p.v. periodiek pollen — zie sources/blitzortung.js
    staleAfterMs: 5 * 60 * 1000, // strenger: community-bron, snel als "haperend" markeren
    implemented: true,
    note: 'Geen officiële API — reverse-engineered WebSocket-protocol, geen SLA. Clustert losse flitsen tot "onweercomplexen" met een naderend/actief/verwijderend-status i.p.v. losse puntflitsen te tonen. Protocol-decodering nog niet live bevestigd — check bij opstarten de console-log "voorbeeldrecord".',
  },
  {
    id: 'p2000',
    categorie: 'hulpdiensten',
    // 2026-08-19: was 'P2000 (Brandweer Berkel-Enschot RSS)' — Lex las dit
    // (begrijpelijk) als "dit incident is in Berkel-Enschot", terwijl het de
    // naam van de landelijke feed-aggregator is (een vrijwilliger die tóevallig
    // in Berkel-Enschot zit, maar het hele land publiceert — bevestigd tegen
    // echte meldingen in Bleiswijk/Vlaardingen/Oudenhoorn/Delft, allemaal met
    // kloppende coördinaten). Naam verduidelijkt zodat 'ie niet als locatie
    // leest.
    naam: 'P2000 Livemonitor (landelijke feed)',
    tier: 'community',
    pollIntervalMs: 90 * 1000,
    staleAfterMs: 10 * 60 * 1000,
    implemented: true,
    note: 'Vrijwilligersfeed, geen officiële overheids-API/SLA. Alleen brandweer/politie/ambulance-items mét coördinaten binnen 25km van huis — zie sources/p2000.js voor het volledige voorbehoud (XML-tagnamen nog niet live bevestigd, check bij opstarten de console-log "voorbeelditem"). Bron-"naam" is de feed-aggregator (landelijk, gevestigd in Berkel-Enschot), niet de incidentlocatie — zie history-comment hierboven.',
  },
  {
    id: 'lifeliner',
    categorie: 'hulpdiensten',
    naam: 'Lifeliner (OpenSky Network)',
    tier: 'community',
    // 2026-08-19: eerst 5→2 min, toen 20s, nu naar 10s — op expliciet verzoek
    // van Lex ("maak de interval zo kort mogelijk"). 10 seconden is de échte
    // technische bodem: OpenSky's anonieme tier rondt zelf al af op een
    // resolutie van 10s (`now - (now mod 10)`, zie hun documentatie) — sneller
    // pollen dan dat kan letterlijk geen nieuwere data opleveren, alleen
    // credits verspillen aan dezelfde momentopname.
    // Dat dit ondanks OpenSky's 400 credits/dag-budget (onze kleine 75km-bbox
    // kost 1 credit/query) toch kan, komt door de twee gates in server.js:
    // `overslaanAlsIdle` (alleen pollen zolang er een client kijkt) én de
    // MMT-dispatch-trigger uit p2000.js (ook zonder kijker doorpollen tot 45
    // min na een mogelijke Lifeliner-uitruk). Lex' eigen gebruikspatroon (1
    // gebruiker, een paar keer per dag een kwartier) houdt dit ruim binnen
    // budget; ENIGE nog niet volledig uitgesloten risico: meerdere MMT-
    // dispatches op één dag terwijl niemand kijkt, kan behoorlijk oplopen
    // (elke trigger = tot 45 min × 6 polls/min = 270 credits). Check
    // /api/status als dit ooit "haperend" laat zien voor lifeliner — dat is
    // het signaal om de trigger-polling (niet de kijk-polling) te vertragen.
    pollIntervalMs: 10 * 1000,
    // Idle-drempel + direct-verversen-bij-terugkeer zit in server.js
    // (IDLE_DREMPEL_MS/isIdle()/signaalVerzoekOntvangen()) — deze vlag
    // schakelt dat gedrag alleen voor déze bron in, want dit is de enige met
    // een harde per-dag credit-limiet bij de bron zelf.
    overslaanAlsIdle: true,
    staleAfterMs: 10 * 60 * 1000,
    implemented: true,
    note: 'Volgt bekende Lifeliner-registraties (PH-TTR/PH-MAA/PH-UMC/PH-HVB/PH-OOP) via OpenSky\'s gratis ADS-B-data binnen 75km van huis, incl. zelf opgebouwd vluchtspoor (geen historie van vóór opstarten). Registratie- en callsign-matching nog niet live bevestigd — zie sources/lifeliner.js. Polt alleen zolang er een client actief is (zie overslaanAlsIdle) om OpenSky\'s anonieme dagbudget te sparen.',
  },
  {
    id: 'moon',
    categorie: 'hemel',
    naam: 'Maanstand (lokale berekening)',
    tier: 'lokaal',
    pollIntervalMs: 60 * 60 * 1000,
    staleAfterMs: null, // lokale berekening is nooit stale
    implemented: true,
  },
  {
    id: 'celestrak',
    categorie: 'hemel',
    naam: 'ISS-passages (g7vrd.co.uk)',
    tier: 'officieel',
    pollIntervalMs: 6 * 60 * 60 * 1000,
    staleAfterMs: 24 * 60 * 60 * 1000,
    implemented: true,
    note: 'Kant-en-klare passage-voorspelling i.p.v. zelf TLE + SGP4 — zie sources/celestrak.js.',
  },
  {
    id: 'swpc',
    categorie: 'hemel',
    naam: 'NOAA SWPC (aurora)',
    tier: 'officieel',
    pollIntervalMs: 30 * 60 * 1000,
    staleAfterMs: 3 * 60 * 60 * 1000,
    implemented: true,
    note: 'OVATION-raster, uitgelezen op HOME_LAT/HOME_LON. Alleen zichtbaar bij waarde ≥5.',
  },
  {
    id: 'donki',
    categorie: 'hemel',
    naam: 'NASA DONKI (ruimteweer-context)',
    tier: 'officieel',
    pollIntervalMs: 6 * 60 * 60 * 1000,
    staleAfterMs: 24 * 60 * 60 * 1000,
    implemented: true,
    note: 'Vereist API-sleutel (DEMO_KEY werkt met lage rate limit, ruim voldoende bij dit poll-interval).',
  },
  {
    id: 'meteors',
    categorie: 'hemel',
    naam: 'Meteorenzwermen (statische kalender)',
    tier: 'lokaal',
    pollIntervalMs: 6 * 60 * 60 * 1000,
    staleAfterMs: null,
    implemented: true,
    note: 'Geen API — lokale kalender, 1x/jaar handmatig bijwerken o.b.v. IMO-jaaroverzicht.',
  },
];

export function getSource(id) {
  return SOURCES.find((s) => s.id === id);
}
