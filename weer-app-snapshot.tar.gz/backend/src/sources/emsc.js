// EMSC SeismicPortal (Europees-Mediterrane focus) — vult USGS aan met kleinere
// bevingen in en rond Europa die USGS' 4.5+-drempel niet haalt.
// Documentatie: https://www.seismicportal.eu/fdsn-wsevent.html
//
// Update t.o.v. de eerdere opzet: dit stond genoteerd als WebSocket-push
// (wss://www.seismicportal.eu/standing_order/websocket), maar de gewone
// FDSN REST-query werkt net zo goed voor pollen en past in het bestaande
// poll-model van de rest van de app — geen aparte WebSocket-laag nodig.
//
// Let op: overlapt deels met USGS voor grote, wereldwijd gevoelde bevingen
// (beide zijn immers officiële seismologische netwerken). Dat kan dus tot
// dubbele meldingen leiden voor hetzelfde fysieke event — bewuste keuze,
// vooralsnog geen cross-source deduplicatie.
import { makeSignal, afstandKm } from '../normalize.js';

const FEED_URL = 'https://www.seismicportal.eu/fdsnws/event/1/query?format=json&limit=50&minmag=3&orderby=time';

function ernstVoorMagnitude(mag) {
  if (mag >= 7) return 'kritiek';
  if (mag >= 5.5) return 'waarschuwing';
  if (mag >= 4) return 'let-op';
  return 'info';
}

export async function fetchEmsc({ homeLat, homeLon }) {
  const res = await fetch(FEED_URL, {
    headers: { 'User-Agent': 'weer-app-persoonlijk (contact: lokaal project)' },
  });
  if (!res.ok) throw new Error(`EMSC feed gaf status ${res.status}`);
  const body = await res.json();

  return (body.features ?? []).map((f) => {
    const [lon, lat] = f.geometry.coordinates;
    const mag = f.properties.mag ?? 0;
    const unid = f.properties.unid ?? f.id;
    return makeSignal({
      id: `emsc-${unid}`,
      categorie: 'aardbeving',
      titel: `M${mag} – ${f.properties.flynn_region ?? 'onbekende regio'}`,
      ernst: ernstVoorMagnitude(mag),
      lat,
      lon,
      tijd: f.properties.time,
      detail: {
        magnitude: mag,
        diepteKm: f.properties.depth != null ? Math.round(f.properties.depth) : null,
        afstandTotJouKm: homeLat != null && homeLon != null ? afstandKm(homeLat, homeLon, lat, lon) : null,
        bron: 'EMSC',
        bronUrl: `https://www.seismicportal.eu/eventdetails.html?unid=${unid}`,
      },
    });
  });
}
