// Iowa Environmental Mesonet — Local Storm Reports (LSR), doorgefilterd op
// TORNADO. Dit zijn geen voorspellingen zoals een Warning/Watch, maar
// daadwerkelijk gemelde/bevestigde tornado's op de grond — spiegelt de
// officiële NWS-LSR-feed. Gratis, geen sleutel.
// https://mesonet.agron.iastate.edu/geojson/lsr.py?help=
//
// Altijd ernst "kritiek": een bevestigde tornado op de grond is per definitie
// het meest urgente wat deze app kan tonen, dringender nog dan een Warning
// (die is een voorspelling, dit is een waarneming).
import { makeSignal } from '../normalize.js';

const VENSTER_MS = 3 * 60 * 60 * 1000; // alleen recente (laatste 3 uur) meldingen — "actuele signalering"

function isoZonderMillis(ms) {
  return new Date(ms).toISOString().replace(/\.\d+Z$/, 'Z');
}

export async function fetchIemLsr() {
  const nu = Date.now();
  const params = new URLSearchParams({
    sts: isoZonderMillis(nu - VENSTER_MS),
    ets: isoZonderMillis(nu),
    wfo: 'ALL',
  });
  const res = await fetch(`https://mesonet.agron.iastate.edu/geojson/lsr.py?${params}`);
  if (!res.ok) throw new Error(`IEM LSR gaf status ${res.status}`);
  const body = await res.json();

  return (body.features ?? [])
    .filter((f) => (f.properties?.typetext ?? '').toUpperCase() === 'TORNADO')
    .map((f) => {
      const p = f.properties;
      const [lon, lat] = f.geometry?.coordinates ?? [null, null];
      const gebied = [p.city, p.county ? `${p.county} County` : null, p.state].filter(Boolean).join(', ');
      return makeSignal({
        id: `iem-lsr-${p.product_id ?? `${p.valid}-${lat}-${lon}`}`,
        categorie: 'tornado-bevestigd',
        titel: `Tornado bevestigd — ${gebied || 'onbekende locatie (VS)'}`,
        ernst: 'kritiek',
        lat,
        lon,
        tijd: p.valid,
        detail: {
          gebied: gebied || null,
          omschrijving: p.remark ?? null,
          bronUrl: 'https://mesonet.agron.iastate.edu/lsr/',
        },
      });
    });
}
