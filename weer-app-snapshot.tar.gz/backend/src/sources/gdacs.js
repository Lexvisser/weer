// GDACS — Global Disaster Alert and Coordination System. Vangnet-bron voor
// rampen die de specifieke bronnen niet dekken: overstromingen, natuurbranden,
// vulkanen, droogte, en cyclonen buiten het bekken dat NHC bedient.
// Docs: https://www.gdacs.org/gdacsapi/ — gratis, geen sleutel.
//
// Bewust: alleen alertlevel Orange/Red komt door. Green betekent bij GDACS
// per definitie "geen significante impact verwacht" en zou de meldingen
// vooral vervuilen — precies het probleem dat we bij aardbevingen al hadden.
import { makeSignal } from '../normalize.js';

const FEED_URL = 'https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH';

const CATEGORIE_PER_TYPE = { EQ: 'aardbeving', TC: 'orkaan', FL: 'overstroming', WF: 'natuurbrand', VO: 'vulkaan', DR: 'droogte' };
const LABEL_PER_TYPE = { EQ: 'Aardbeving', TC: 'Cycloon', FL: 'Overstroming', WF: 'Natuurbrand', VO: 'Vulkaanuitbarsting', DR: 'Droogte' };
const ERNST_PER_ALERTLEVEL = { Red: 'kritiek', Orange: 'waarschuwing', Green: 'info' };

// GDACS geeft "country" vaak als kommagescheiden lijst van álle getroffen
// landen terug (bij een grote cycloon kan dat zomaar 6+ landen zijn) — te
// lang en verwarrend om in een titel te proppen. Verkort tot maximaal 2
// namen + een telling; de volledige lijst blijft beschikbaar in detail.land.
function verkorteLandenlijst(land) {
  if (!land) return null;
  const landen = land.split(',').map((l) => l.trim()).filter(Boolean);
  if (landen.length <= 2) return landen.join(', ');
  return `${landen[0]} e.a. (${landen.length} landen)`;
}

export async function fetchGdacs() {
  const res = await fetch(FEED_URL, { headers: { 'User-Agent': 'weer-app-persoonlijk (contact: lokaal project)' } });
  if (!res.ok) throw new Error(`GDACS feed gaf status ${res.status}`);
  const body = await res.json();

  return (body.features ?? [])
    .filter((f) => f.properties.alertlevel === 'Orange' || f.properties.alertlevel === 'Red')
    .map((f) => {
      const p = f.properties;
      const [lon, lat] = f.geometry?.coordinates ?? [null, null];
      const type = p.eventtype;
      // Cyclonen krijgen bij GDACS meestal een eigen naam in eventname (bijv.
      // "MELISSA-25") — andere hazard-types laten dat veld vaak leeg. Zónder
      // naam is de (verkorte) landenlijst de enige onderscheidende titel-tekst;
      // mét naam is de naam al onderscheidend genoeg en houden we de titel kort
      // (de volledige landenlijst staat nog gewoon in detail.land).
      const naamDeel = p.eventname ? ` ${p.eventname}` : '';
      const titel = p.eventname
        ? `${LABEL_PER_TYPE[type] ?? type}${naamDeel}`
        : `${LABEL_PER_TYPE[type] ?? type} – ${verkorteLandenlijst(p.country) ?? p.name ?? 'onbekend gebied'}`;
      return makeSignal({
        id: `gdacs-${type}-${p.eventid}-${p.episodeid ?? 0}`,
        categorie: CATEGORIE_PER_TYPE[type] ?? 'multi-hazard',
        titel,
        ernst: ERNST_PER_ALERTLEVEL[p.alertlevel] ?? 'info',
        lat,
        lon,
        tijd: p.fromdate,
        detail: {
          naam: p.eventname ?? null,
          land: p.country ?? null,
          gdacsAlertlevel: p.alertlevel,
          samenvatting: p.severitydata?.severitytext ?? p.name ?? null,
          bronUrl: `https://www.gdacs.org/report.aspx?eventid=${p.eventid}&eventtype=${type}`,
        },
      });
    });
}
