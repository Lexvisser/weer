// ISS-passages. In plaats van zelf TLE's ophalen en SGP4-baanpropagatie
// bouwen (niet-triviaal, en botst met het zero-dependency-uitgangspunt) een
// kant-en-klare gratis "wanneer is de ISS hier zichtbaar"-API: g7vrd.co.uk.
// Geen sleutel nodig, live geverifieerd op 2026-08-17 tegen HOME_LAT/HOME_LON.
// https://api.g7vrd.co.uk/v1/satellite-passes/{norad-id}/{lat}/{lon}.json
//
// Aanname (zoals vergelijkbare "spot the station"-diensten): dit voorspelt
// écht zichtbare passages — dus ISS in zonlicht én waarnemer in het donker —
// niet alleen een kale geometrische "boven de horizon"-berekening. Nog te
// bevestigen door 'm een keer live te vergelijken met een echte waarneming.
import { makeSignal } from '../normalize.js';

const NORAD_ID_ISS = 25544;
const WINDRICHTINGEN = ['N', 'NO', 'O', 'ZO', 'Z', 'ZW', 'W', 'NW'];

function windrichting(graden) {
  if (graden == null) return '—';
  return WINDRICHTINGEN[Math.round(graden / 45) % 8];
}

export async function fetchCelestrak({ homeLat, homeLon }) {
  const lat = homeLat ?? 52.09;
  const lon = homeLon ?? 5.12;
  const res = await fetch(`https://api.g7vrd.co.uk/v1/satellite-passes/${NORAD_ID_ISS}/${lat}/${lon}.json`);
  if (!res.ok) throw new Error(`g7vrd ISS-passages gaf status ${res.status}`);
  const body = await res.json();

  return (body.passes ?? []).slice(0, 4).map((p) => {
    const start = new Date(p.start);
    const eind = new Date(p.end);
    const duurMinuten = Math.round((eind - start) / 60000);
    const tijdTekst = new Intl.DateTimeFormat('nl-NL', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Europe/Amsterdam',
    }).format(start);
    const maxElevatie = Math.round(p.max_elevation);

    return makeSignal({
      id: `iss-${p.start}`,
      categorie: 'hemel',
      titel: `ISS-passage om ${tijdTekst} — max. ${maxElevatie}° (${duurMinuten} min)`,
      ernst: maxElevatie >= 50 ? 'let-op' : 'info',
      tijd: p.start,
      detail: {
        starttijd: p.start,
        eindtijd: p.end,
        maxElevatieGraden: maxElevatie,
        richtingOp: windrichting(p.aos_azimuth),
        richtingOnder: windrichting(p.los_azimuth),
        duurMinuten,
        bronUrl: 'https://spotthestation.nasa.gov/',
      },
    });
  });
}
