// USGS Earthquake Feed — gratis, geen sleutel nodig.
// Documentatie: https://earthquake.usgs.gov/earthquakes/feed/v1.0/geojson.php
import { makeSignal, afstandKm } from '../normalize.js';

const FEED_URL = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson';

function ernstVoorMagnitude(mag) {
  if (mag >= 7) return 'kritiek';
  if (mag >= 5.5) return 'waarschuwing';
  if (mag >= 4.5) return 'let-op';
  return 'info';
}

// ---- ShakeMap-plaatje, 2026-08-18 ------------------------------------------
// Op verzoek van Lex: "actuele fototjes van de situatie". Niet elke beving
// heeft een ShakeMap (vereist voldoende seismometer-dichtheid rond het
// epicentrum) — de summary-feed geeft per beving alvast een "types"-lijst
// mee die dat verraadt, dus we proberen de per-beving detail-feed (met de
// daadwerkelijke plaatje-URL) alleen op te halen als "shakemap" daar ook in
// staat. Module-brede cache: eenmaal opgehaald (of bevestigd afwezig) hoeft
// dat niet elke poll-cyclus (90s) opnieuw voor dezelfde beving. Best-effort:
// lukt het niet, dan blijft de beving gewoon zonder plaatje bestaan.
const shakemapCache = new Map(); // usgs event-id -> url | null

async function shakemapUrlVoor(f) {
  const id = f.id;
  if (shakemapCache.has(id)) return shakemapCache.get(id);
  const types = String(f.properties?.types ?? '');
  if (!types.includes('shakemap') || !f.properties?.detail) {
    shakemapCache.set(id, null);
    return null;
  }
  try {
    const res = await fetch(f.properties.detail, {
      headers: { 'User-Agent': 'weer-app-persoonlijk (contact: lokaal project)' },
    });
    if (!res.ok) throw new Error(`detail-feed gaf status ${res.status}`);
    const body = await res.json();
    const contents = body.properties?.products?.shakemap?.[0]?.contents ?? {};
    const url = contents['download/intensity.jpg']?.url ?? null;
    shakemapCache.set(id, url);
    return url;
  } catch (err) {
    console.error(`[weer] usgs shakemap ophalen mislukt voor ${id}:`, err.message ?? err);
    shakemapCache.set(id, null); // niet elke cyclus opnieuw proberen bij een structurele fout
    return null;
  }
}

export async function fetchUsgs({ homeLat, homeLon }) {
  const res = await fetch(FEED_URL, {
    headers: { 'User-Agent': 'weer-app-persoonlijk (contact: lokaal project)' },
  });
  if (!res.ok) throw new Error(`USGS feed gaf status ${res.status}`);
  const body = await res.json();

  return Promise.all(
    body.features.map(async (f) => {
      const [lon, lat, diepteKm] = f.geometry.coordinates;
      const mag = f.properties.mag ?? 0;
      return makeSignal({
        id: `usgs-${f.id}`,
        categorie: 'aardbeving',
        titel: f.properties.title ?? `Aardbeving M${mag}`,
        ernst: ernstVoorMagnitude(mag),
        lat,
        lon,
        tijd: new Date(f.properties.time).toISOString(),
        detail: {
          magnitude: mag,
          diepteKm: Math.round(diepteKm),
          afstandTotJouKm: homeLat != null && homeLon != null ? afstandKm(homeLat, homeLon, lat, lon) : null,
          voelbaarMeldingen: f.properties.felt ?? null,
          bronUrl: f.properties.url,
          shakemapUrl: await shakemapUrlVoor(f),
        },
      });
    })
  );
}
