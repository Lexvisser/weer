// Reddit — publieke, sleutelloze search-API (search.json), voor community-
// foto's/video's bij een actief hazard-signaal. Op verzoek van Lex: "foto's
// van de community mogen erbij". Reddit is het enige grote platform met een
// authenticatie-vrije publieke listing-endpoint; X/Twitter en Instagram
// vereisen tegenwoordig een (vaak betaald) developer-account, dus die vielen
// af.
//
// Let op: dit is ONGEMODEREERDE community-content — af en toe irrelevante of
// rommelige resultaten. De frontend toont daarom altijd een expliciet
// "community, ongecontroleerd"-label erbij (zie popupFotostripHtml in
// app.js) i.p.v. het te laten doorgaan voor officiële beeldmateriaal. Posts
// met over_18=true en video-posts worden hier al weggefilterd, maar verder
// is er geen inhoudelijke moderatie — bewuste keuze, net als bij de andere
// "best effort, nooit de hele bron laten falen"-bronnen in dit project.
const SUBREDDITS = 'TropicalWeather+weather+hurricane';

export async function fetchCommunityFotos(zoekterm, limiet = 4) {
  if (!zoekterm) return [];
  try {
    const url = `https://www.reddit.com/r/${SUBREDDITS}/search.json?q=${encodeURIComponent(zoekterm)}&restrict_sr=1&sort=new&limit=15`;
    const res = await fetch(url, {
      headers: { 'User-Agent': 'weer-app-persoonlijk/1.0 (contact: lokaal project)' },
    });
    if (!res.ok) throw new Error(`Reddit search gaf status ${res.status}`);
    const body = await res.json();
    const posts = body.data?.children ?? [];
    return posts
      .map((p) => p.data)
      .filter((p) => p && !p.over_18 && !p.is_video)
      .filter((p) => p.post_hint === 'image' || /\.(jpg|jpeg|png|gif)$/i.test(p.url ?? ''))
      .slice(0, limiet)
      .map((p) => ({
        url: p.url,
        thumbUrl: p.thumbnail && p.thumbnail.startsWith('http') ? p.thumbnail : p.url,
        titel: p.title,
        link: `https://reddit.com${p.permalink}`,
      }));
  } catch (err) {
    console.error(`[weer] reddit community-foto's ophalen mislukt voor "${zoekterm}":`, err.message ?? err);
    return [];
  }
}
