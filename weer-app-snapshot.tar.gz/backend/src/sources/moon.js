// Maanstand — geen externe bron nodig, dit is pure astronomische berekening.
// Referentie-nieuwe-maan: 2000-01-06 18:14 UTC. Synodische maand: 29.53058867 dagen.
import { makeSignal } from '../normalize.js';

const REFERENCE_NEW_MOON = Date.UTC(2000, 0, 6, 18, 14);
const SYNODIC_MONTH_DAYS = 29.53058867;

function faseNaam(fractie) {
  if (fractie < 0.02 || fractie > 0.98) return 'Nieuwe maan';
  if (fractie < 0.25) return 'Wassende sikkel';
  if (fractie < 0.27) return 'Eerste kwartier';
  if (fractie < 0.48) return 'Wassende maan';
  if (fractie < 0.52) return 'Volle maan';
  if (fractie < 0.73) return 'Afnemende maan';
  if (fractie < 0.77) return 'Laatste kwartier';
  return 'Afnemende sikkel';
}

export async function fetchMoon() {
  const now = Date.now();
  const daysSince = (now - REFERENCE_NEW_MOON) / 86400000;
  const fractie = ((daysSince % SYNODIC_MONTH_DAYS) + SYNODIC_MONTH_DAYS) % SYNODIC_MONTH_DAYS / SYNODIC_MONTH_DAYS;
  const illuminatie = Math.round((1 - Math.cos(2 * Math.PI * fractie)) / 2 * 100);
  const wassend = fractie < 0.5;

  return [
    makeSignal({
      id: 'moon-today',
      categorie: 'hemel',
      titel: faseNaam(fractie),
      ernst: 'info',
      tijd: new Date().toISOString(),
      detail: {
        illuminatiePercentage: illuminatie,
        wassend,
        faseFractie: Number(fractie.toFixed(4)),
      },
    }),
  ];
}
