// Meteoalarm — Europese severe-weather-waarschuwingen, officiële bron voor
// NL-waarschuwingen (KNMI levert hieraan). Legacy Atom+CAP-feed, gratis, geen
// sleutel. https://feeds.meteoalarm.org/feeds/meteoalarm-legacy-atom-netherlands
//
// Eerder als stub gelaten uit zorg dat waarschuwingsdetails in een HTML-tabel
// binnen <summary> zouden zitten — te lastig om zonder XML-dependency
// betrouwbaar te ontleden. Op 2026-08-17 getest tegen landen mét een actieve
// waarschuwing (Griekenland, Italië — NL zelf had op dat moment niets actiefs):
// de legacy-feed blijkt gewoon platte, consistent genoemde cap:-tags te
// gebruiken (cap:areaDesc, cap:event, cap:severity, cap:effective,
// cap:expires, ...), geen HTML-tabel. Een simpele regex-parser is hier dus
// verantwoord — met een try/catch per entry zodat één onverwacht afwijkende
// entry niet de hele poll laat mislukken.
//
// Geen lat/lon beschikbaar (alleen een regiocode, geen coördinaten) — deze
// signalen krijgen dus geen kaartpin, maar wel een eigen categorie
// ('weerwaarschuwing', niet uitgesloten in de Meldingen-lijst) zodat ze niet
// onzichtbaar wegvallen.
import { makeSignal } from '../normalize.js';

const FEED_URL = 'https://feeds.meteoalarm.org/feeds/meteoalarm-legacy-atom-netherlands';

const ERNST_PER_SEVERITY = { Extreme: 'kritiek', Severe: 'waarschuwing', Moderate: 'let-op', Minor: 'info' };

function decodeEntities(str) {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function tag(xml, naam) {
  const match = xml.match(new RegExp(`<${naam}>([\\s\\S]*?)</${naam}>`));
  return match ? decodeEntities(match[1].trim()) : null;
}

function splitsEntries(xml) {
  const blokken = [];
  const re = /<entry>([\s\S]*?)<\/entry>/g;
  let m;
  while ((m = re.exec(xml))) blokken.push(m[1]);
  return blokken;
}

export async function fetchMeteoalarm() {
  const res = await fetch(FEED_URL);
  if (!res.ok) throw new Error(`Meteoalarm feed gaf status ${res.status}`);
  const xml = await res.text();
  const nu = Date.now();
  const signalen = [];

  for (const blok of splitsEntries(xml)) {
    try {
      const expires = tag(blok, 'cap:expires');
      if (!expires || new Date(expires).getTime() <= nu) continue; // al verlopen, overslaan

      const areaDesc = tag(blok, 'cap:areaDesc') ?? 'Nederland';
      const event = tag(blok, 'cap:event') ?? 'Weerwaarschuwing';
      const severity = tag(blok, 'cap:severity');
      const id = tag(blok, 'id') ?? `${areaDesc}-${event}-${expires}`;

      signalen.push(
        makeSignal({
          id: `meteoalarm-${id}`,
          categorie: 'weerwaarschuwing',
          titel: `${event} – ${areaDesc}`,
          ernst: ERNST_PER_SEVERITY[severity] ?? 'let-op',
          tijd: tag(blok, 'cap:effective') ?? tag(blok, 'cap:sent') ?? new Date().toISOString(),
          detail: {
            gebied: areaDesc,
            severity: severity ?? null,
            certainty: tag(blok, 'cap:certainty'),
            urgency: tag(blok, 'cap:urgency'),
            geldigTot: expires,
            bronUrl: 'https://meteoalarm.org/',
          },
        }),
      );
    } catch (err) {
      console.error('[weer] kon een Meteoalarm-entry niet parsen:', err.message ?? err);
    }
  }

  return signalen;
}
