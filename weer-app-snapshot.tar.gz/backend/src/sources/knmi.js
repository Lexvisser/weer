// KNMI Open Data — Nederlands weer/waarschuwingen.
// Docs + gratis sleutel: https://developer.dataplatform.knmi.nl/
// Anonieme sleutel: 50 req/min. Geregistreerde sleutel: 200 req/s.
//
// Bewust nog niet geïmplementeerd: dit vereist een persoonlijke, geregistreerde
// sleutel (KNMI_API_KEY in .env staat nu leeg) — geen "gratis, geen sleutel"-bron
// zoals de rest. Open-Meteo dekt de actuele cijfers al, en zodra meteoalarm.js
// klaar is dekt dat de officiële NL-waarschuwingen. KNMI Open Data zou er vooral
// als NL-specifieke precisieverbetering bovenop komen — lage prioriteit.
//
// TODO: KNMI_API_KEY uit .env gebruiken, juiste dataset kiezen (observaties/waarschuwingen)
// en omzetten naar Signal[] met categorie 'algemeen-weer'.

export async function fetchKnmi(_env) {
  return [];
}
