// NOAA National Hurricane Center — orkaan-tracking.
// Gebruikt het simpele JSON-overzicht i.p.v. de losse RSS/GIS-lagen:
// https://www.nhc.noaa.gov/CurrentStorms.json
// Gratis, geen sleutel. Geen officiële uptime-garantie (NOAA-disclaimer).
import { makeSignal, afstandKm } from '../normalize.js';
import { fetchCommunityFotos } from './reddit.js';

const FEED_URL = 'https://www.nhc.noaa.gov/CurrentStorms.json';

// ---- Voorspelde koers (forecast track + cone of uncertainty), 2026-08-17 --
// Op verzoek van Lex ("kan je ook predicted path opgeven grafisch voor
// cyclones?"). CurrentStorms.json zelf bevat dit niet — NHC publiceert het
// als aparte ArcGIS-lagen, één "Forecast Cone"/"Forecast Track"-laag per
// momenteel actieve storm-*slot* (AT1..AT5 Atlantische Oceaan, EP1..EP5/
// CP1..CP5 Oost-/Centraal-Pacific). Welk slot bij welke storm hoort
// verandert continu (storms komen en gaan), en welk eigenschap-veld de
// stormnaam bevat kon niet live geverifieerd worden vanuit deze omgeving
// (zelfde beperking als bij andere nieuwe bronnen — de sandbox/webfetch-
// tooling kreeg alleen de interactieve HTML-queryinterface van deze ArcGIS-
// service terug, geen ruwe JSON). Daarom koppelen we NIET op naam, maar op
// geometrie: het eerste punt van een forecast-cone/track ligt per definitie
// vlak bij de huidige positie van de storm waar 'm bij hoort (een cone
// begint letterlijk bij het stormcentrum), dus we zoeken de dichtstbijzijnde
// actieve storm uit CurrentStorms.json — met een ruime veiligheidsmarge.
const MAPSERVER =
  'https://mapservices.weather.noaa.gov/tropical/rest/services/tropical/NHC_tropical_weather/MapServer';
// Moet vrijwel altijd <50km zijn (cone begint bij het stormcentrum) — 300km
// als ruime marge tegen kleine afrondingsverschillen tussen de twee bronnen.
const KOPPEL_MARGE_KM = 300;

// GeoJSON is [lon, lat] — Leaflet/de rest van deze app wil [lat, lon].
function alsLatLon([lon, lat]) {
  return [lat, lon];
}

async function fetchLaagFeatures(mapserver, laagId) {
  const url = `${mapserver}/${laagId}/query?f=geojson&where=1%3D1&outFields=*&returnGeometry=true`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`laag ${laagId} gaf status ${res.status}`);
  const body = await res.json();
  return body.features ?? [];
}

function dichtstbijzijndeStormFactory(storms, margeKm) {
  return function dichtstbijzijndeStorm(lat, lon) {
    let beste = null;
    let besteAfstand = Infinity;
    for (const storm of storms) {
      if (storm.latitudeNumeric == null || storm.longitudeNumeric == null) continue;
      const d = afstandKm(lat, lon, storm.latitudeNumeric, storm.longitudeNumeric);
      if (d < besteAfstand) {
        besteAfstand = d;
        beste = storm;
      }
    }
    return beste && besteAfstand <= margeKm ? beste : null;
  };
}

// Best effort: als dit om wat voor reden dan ook mislukt (NHC-laagstructuur
// gewijzigd, netwerkhapering, veldnamen anders dan verwacht), gaan de
// orkaan-signalen gewoon door zonder voorspelde koers i.p.v. dat de hele
// bron faalt — een orkaan-signaal zonder koers-extra is nog altijd veel
// waardevoller dan helemaal geen orkaan-signaal.
async function fetchVoorspeldeKoersen(storms) {
  const koersenPerStorm = new Map(); // storm.id -> { gebiedPolygon, koerslijn }
  if (!storms.length) return koersenPerStorm;
  try {
    const res = await fetch(`${MAPSERVER}/layers?f=json`);
    if (!res.ok) throw new Error(`lagenlijst gaf status ${res.status}`);
    const body = await res.json();
    const lagen = body.layers ?? [];
    const coneLagen = lagen.filter((l) => /forecast cone$/i.test(l.name ?? ''));
    const trackLagen = lagen.filter((l) => /forecast track$/i.test(l.name ?? ''));
    const dichtstbijzijndeStorm = dichtstbijzijndeStormFactory(storms, KOPPEL_MARGE_KM);

    await Promise.allSettled([
      ...coneLagen.map(async (laag) => {
        const features = await fetchLaagFeatures(MAPSERVER, laag.id);
        for (const f of features) {
          const ring = f.geometry?.coordinates?.[0];
          if (!Array.isArray(ring) || !ring.length) continue;
          const [lon, lat] = ring[0];
          const storm = dichtstbijzijndeStorm(lat, lon);
          if (!storm) continue;
          const entry = koersenPerStorm.get(storm.id) ?? {};
          entry.gebiedPolygon = [ring.map(alsLatLon)];
          koersenPerStorm.set(storm.id, entry);
        }
      }),
      ...trackLagen.map(async (laag) => {
        const features = await fetchLaagFeatures(MAPSERVER, laag.id);
        for (const f of features) {
          const lijn = f.geometry?.coordinates;
          if (!Array.isArray(lijn) || !lijn.length) continue;
          const [lon, lat] = lijn[0];
          const storm = dichtstbijzijndeStorm(lat, lon);
          if (!storm) continue;
          const entry = koersenPerStorm.get(storm.id) ?? {};
          entry.koerslijn = lijn.map(alsLatLon);
          koersenPerStorm.set(storm.id, entry);
        }
      }),
    ]);

    if (koersenPerStorm.size) {
      console.log(`[weer] nhc-forecast: voorspelde koers gekoppeld voor ${koersenPerStorm.size} storm(en)`);
    } else if (coneLagen.length || trackLagen.length) {
      console.log(
        `[weer] nhc-forecast: ${coneLagen.length} cone-laag/lagen en ${trackLagen.length} track-laag/lagen ` +
          `gevonden, maar geen kon aan een actieve storm gekoppeld worden (>${KOPPEL_MARGE_KM}km weg, of storm ` +
          `zonder positie) — check de koppel-logica hierboven als dit blijft gebeuren zodra er echt een actieve ` +
          `storm is.`
      );
    }
  } catch (err) {
    console.error(
      '[weer] nhc-forecast poll mislukt (orkaan-signalen gaan gewoon door zonder voorspelde koers):',
      err.message ?? err
    );
  }
  return koersenPerStorm;
}

// ---- Live satellietbeeld (GOES GeoColor) — weggehaald, 2026-08-18 ----------
// Stond hier eerst als los, statisch STAR CDN-plaatje per storm-popup (naast
// SATELLIET_PER_BASIN + satellietUrlVoor()). Op verzoek van Lex weggehaald
// nadat de interactieve GIBS-kaartlaag (🛰️ Satelliet-knop, zie app.js) eenmaal
// goed werkte: "valt uit beeld, meer last dan gemak, overkill" — dat vaste
// plaatje toonde in essentie hetzelfde als de kaartlaag, maar dan niet te
// verschuiven/inzoomen. De sectornaam-uitzoekklus (`hi` voor Centraal-Pacific,
// bevestigd bij Lala; `eep` voor Oost-Pacific, ongeteste gok; `taw` voor het
// Atlantische bekken, bevestigd) is destijds nuttig gebleken voor de mapindex-
// kennis, maar de feature zelf is dus niet meer in gebruik.

// ---- Volledige advisory-tekst, 2026-08-18 -----------------------------------
// Haalt de tekst van storm.publicAdvisory.url op (een .shtml-pagina met de
// ruwe NWS-bulletintekst in een <pre>-blok) en toont die direct in de app
// i.p.v. alleen een link erheen. Paginastructuur niet live geverifieerd
// vanuit deze omgeving — best-effort <pre>-extractie; lukt het niet, dan
// blijft gewoon alleen de link over (die stond er toch al).
async function fetchAdviesTekst(url) {
  try {
    const res = await fetch(url, { headers: { 'User-Agent': 'weer-app-persoonlijk (contact: lokaal project)' } });
    if (!res.ok) throw new Error(`advisory-pagina gaf status ${res.status}`);
    const html = await res.text();
    const match = html.match(/<pre[^>]*>([\s\S]*?)<\/pre>/i);
    if (!match) return null;
    const tekst = match[1]
      .replace(/<[^>]+>/g, '')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&nbsp;/g, ' ')
      .trim();
    return tekst.slice(0, 4000) || null;
  } catch (err) {
    console.error('[weer] nhc-advies-tekst ophalen mislukt:', err.message ?? err);
    return null;
  }
}

// ---- Storm surge watch/warning, 2026-08-18 ----------------------------------
// Aparte, FEMA-gehoste ArcGIS-service (niet dezelfde MAPSERVER als hierboven)
// — gevonden via een live zoekopdracht, maar laagstructuur/veldnamen niet
// geverifieerd. Best-effort en bewust beperkt tot een korte statustekst (geen
// polygon-tekening) — dat houdt het risico van een derde, onzekere geometrie
// naast gebiedPolygon/koerslijn buiten de deur. Gekoppeld op dezelfde
// dichtstbijzijnde-storm-truc als de voorspelde koers hierboven, met een
// ruimere marge (surge-zones liggen aan de kust, niet bij het stormcentrum).
const SURGE_MAPSERVER = 'https://gis.fema.gov/arcgis/rest/services/Partner/NHC_Hur_Adv_Surge/MapServer';
const SURGE_KOPPEL_MARGE_KM = 1000;

async function fetchStormSurgeTeksten(storms) {
  const resultaat = new Map(); // storm.id -> tekst
  if (!storms.length) return resultaat;
  try {
    const res = await fetch(`${SURGE_MAPSERVER}/layers?f=json`);
    if (!res.ok) throw new Error(`surge-lagenlijst gaf status ${res.status}`);
    const body = await res.json();
    const lagen = (body.layers ?? []).filter((l) => /watch|warning/i.test(l.name ?? ''));
    if (!lagen.length) return resultaat;
    const dichtstbijzijndeStorm = dichtstbijzijndeStormFactory(storms, SURGE_KOPPEL_MARGE_KM);

    await Promise.allSettled(
      lagen.map(async (laag) => {
        const features = await fetchLaagFeatures(SURGE_MAPSERVER, laag.id);
        const isWarning = /warning/i.test(laag.name ?? '');
        for (const f of features) {
          const ring = f.geometry?.coordinates?.[0];
          if (!Array.isArray(ring) || !ring.length) continue;
          const [lon, lat] = ring[0];
          const storm = dichtstbijzijndeStorm(lat, lon);
          if (!storm) continue;
          const huidigIsWarning = resultaat.get(storm.id)?.includes('WARNING');
          if (!huidigIsWarning) {
            resultaat.set(
              storm.id,
              isWarning
                ? 'Storm surge WARNING actief langs (delen van) de kust'
                : 'Storm surge watch actief langs (delen van) de kust'
            );
          }
        }
      })
    );
  } catch (err) {
    console.error(
      '[weer] nhc storm-surge-check mislukt (orkaan-signaal gaat gewoon door zonder surge-info):',
      err.message ?? err
    );
  }
  return resultaat;
}

// ---- Tropical Weather Outlook (vormingsgebieden), 2026-08-18 ---------------
// Op verzoek van Lex: vroege waarschuwing vóórdat een systeem een naam heeft.
// NHC's "Graphical Tropical Weather Outlook" (zie nhc.noaa.gov/gis/) toont
// gebieden met een ontwikkelingskans (2-daags/7-daags). Eigen, losse signalen
// (geen koppeling aan een bestaande storm nodig — deze gebieden bestaan vaak
// zonder dat er al een storm is), categorie 'cycloonvorming'.
//
// FIX 2026-08-19: Lex zag een live 80%-Pacific-disturbance op nhc.gov die
// nooit als signaal in de app verscheen — geen basin-probleem (deze bron
// dekt sowieso alle NHC-bekkens, geen filter), maar een echte bug, live
// bevestigd door de NHC-laagstructuur zelf op te vragen:
// 1. De oorspronkelijke regex-match op "outlook" in de laagnaam matchte
//    alleen twee lege GROEP-lagen ("Graphical Tropical Weather Outlook" en
//    "Seven-Day Outlook") — containers zonder eigen features, een query
//    daarop levert altijd niks op. De laag met de daadwerkelijke gearceerde
//    vormingsgebieden heet "Seven-Day: Potential Development Region" — geen
//    "outlook" in de naam, dus werd nooit gevonden.
// 2. De gegokte veldnamen (PERCENTAGE/PROB7DAY in hoofdletters) klopten ook
//    niet — de echte velden zijn kleine letters: prob2day/prob7day (percentage)
//    en risk2day/risk7day (NHC's eigen tekstomschrijving, bijv. "High...80
//    percent"). Beide bugs samen zorgden dus dat dit stilzwijgend nooit iets
//    opleverde, ook al klopte de basin-dekking (Atlantic+Pacific) prima.
// Nu direct op de juiste laagnaam gematcht, met de live geverifieerde
// veldnamen als primaire keuze (oude hoofdletter-gok als vangnet erachteraan
// voor het geval NOAA het schema ooit weer wijzigt).
async function fetchOutlookGebieden() {
  try {
    const res = await fetch(`${MAPSERVER}/layers?f=json`);
    if (!res.ok) throw new Error(`lagenlijst gaf status ${res.status}`);
    const body = await res.json();
    const lagen = (body.layers ?? []).filter((l) => /potential development region/i.test(l.name ?? ''));
    if (!lagen.length) return [];

    const featuresPerLaag = await Promise.allSettled(lagen.map((l) => fetchLaagFeatures(MAPSERVER, l.id)));
    const signalen = [];
    featuresPerLaag.forEach((r, i) => {
      if (r.status !== 'fulfilled') return;
      r.value.forEach((f, j) => {
        const ring = f.geometry?.coordinates?.[0];
        if (!Array.isArray(ring) || ring.length < 3) return;
        const props = f.properties ?? {};
        const kansPct = Number(
          props.prob7day ?? props.prob2day ?? props.PERCENTAGE ?? props.PROB7DAY ?? props.PROB2DAY ?? props.OUTLOOKPROB ?? props.PROB ?? NaN,
        );
        const kansTekst = Number.isFinite(kansPct) ? `${kansPct}% kans op ontwikkeling (7 dagen)` : null;
        const som = ring.reduce((acc, [lon, lat]) => [acc[0] + lat, acc[1] + lon], [0, 0]);
        const zwaartepunt = [som[0] / ring.length, som[1] / ring.length];
        signalen.push(
          makeSignal({
            id: `nhc-outlook-${lagen[i].id}-${j}`,
            categorie: 'cycloonvorming',
            titel: kansTekst ? `Mogelijke tropische ontwikkeling — ${kansTekst}` : 'Mogelijke tropische ontwikkeling',
            ernst: Number.isFinite(kansPct) && kansPct >= 60 ? 'let-op' : 'info',
            lat: zwaartepunt[0],
            lon: zwaartepunt[1],
            tijd: new Date().toISOString(),
            detail: {
              kansTekst,
              basin: props.basin ?? null,
              risicoTekst2Dagen: props.risk2day ?? null,
              risicoTekst7Dagen: props.risk7day ?? null,
              gebiedPolygon: [ring.map(alsLatLon)],
            },
          })
        );
      });
    });
    if (signalen.length) console.log(`[weer] nhc-outlook: ${signalen.length} vormingsgebied(en) gevonden`);
    return signalen;
  } catch (err) {
    console.error('[weer] nhc-outlook poll mislukt (vormingsgebieden overgeslagen):', err.message ?? err);
    return [];
  }
}

const CLASSIFICATIE_NAAM = {
  TD: 'Tropische depressie',
  TS: 'Tropische storm',
  HU: 'Orkaan',
  PTC: 'Potentiële tropische cycloon',
};

// Saffir-Simpson-categorie op basis van windsnelheid in knopen (alleen relevant bij HU).
function orkaanCategorie(intensiteitKt) {
  if (intensiteitKt >= 137) return 5;
  if (intensiteitKt >= 113) return 4;
  if (intensiteitKt >= 96) return 3;
  if (intensiteitKt >= 83) return 2;
  if (intensiteitKt >= 64) return 1;
  return null;
}

function ernstVoor(classificatie, intensiteitKt) {
  if (classificatie === 'HU') {
    const cat = orkaanCategorie(intensiteitKt);
    return cat >= 3 ? 'kritiek' : 'waarschuwing';
  }
  if (classificatie === 'TS' || classificatie === 'PTC') return 'let-op';
  return 'info'; // TD en overig
}

export async function fetchNhc() {
  const res = await fetch(FEED_URL, {
    headers: { 'User-Agent': 'weer-app-persoonlijk (contact: lokaal project)' },
  });
  if (!res.ok) throw new Error(`NHC feed gaf status ${res.status}`);
  const body = await res.json();
  const storms = body.activeStorms ?? [];

  const [koersenPerStorm, surgeTekstenPerStorm, verrijkingenPerStorm, outlookSignalen] = await Promise.all([
    fetchVoorspeldeKoersen(storms),
    fetchStormSurgeTeksten(storms),
    Promise.all(
      storms.map(async (storm) => {
        const [advies, fotos] = await Promise.all([
          storm.publicAdvisory?.url ? fetchAdviesTekst(storm.publicAdvisory.url) : Promise.resolve(null),
          fetchCommunityFotos(storm.name),
        ]);
        return [storm.id, { adviesTekst: advies, communityFotos: fotos }];
      })
    ).then((paren) => new Map(paren)),
    fetchOutlookGebieden(),
  ]);

  const stormSignalen = storms.map((storm) => {
    const intensiteitKt = Number(storm.intensity);
    const classificatie = storm.classification;
    const cat = classificatie === 'HU' ? orkaanCategorie(intensiteitKt) : null;
    const naam = CLASSIFICATIE_NAAM[classificatie] ?? classificatie;
    const titel = cat ? `${naam} ${storm.name} — Cat. ${cat}` : `${naam} ${storm.name}`;
    const koers = koersenPerStorm.get(storm.id);
    const verrijking = verrijkingenPerStorm.get(storm.id) ?? {};

    return makeSignal({
      id: `nhc-${storm.id}`,
      categorie: 'orkaan',
      titel,
      ernst: ernstVoor(classificatie, intensiteitKt),
      lat: storm.latitudeNumeric,
      lon: storm.longitudeNumeric,
      tijd: storm.lastUpdate,
      detail: {
        classificatie,
        categorieOrkaan: cat,
        windKt: intensiteitKt,
        drukHpa: storm.pressure ? Number(storm.pressure) : null,
        bewegingRichtingGraden: storm.movementDir ?? null,
        bewegingSnelheidKt: storm.movementSpeed ?? null,
        publicAdvisoryUrl: storm.publicAdvisory?.url ?? null,
        // Voorspelde koers (cone of uncertainty + track-lijn) — alleen voor
        // NHC-orkanen (Atlantische/Oost-/Centraal-Pacifische bekkens), zie
        // fetchVoorspeldeKoersen() hierboven. null zolang niet gekoppeld kon
        // worden; hergebruikt dezelfde toonGebiedVoor()-tekenlogica in de
        // frontend als tornado-watch/severe-outlook (gebiedPolygon) plus een
        // polylijn-tekening (koerslijn).
        gebiedPolygon: koers?.gebiedPolygon ?? null,
        koerslijn: koers?.koerslijn ?? null,
        // Nieuw sinds 2026-08-18 (zie fetch*-functies hierboven voor de
        // achtergrond/onzekerheden per veld):
        adviesTekst: verrijking.adviesTekst ?? null,
        communityFotos: verrijking.communityFotos ?? [],
        stormSurgeTekst: surgeTekstenPerStorm.get(storm.id) ?? null,
      },
    });
  });

  // outlookSignalen (categorie 'cycloonvorming') zijn losse signalen, niet
  // gekoppeld aan een storm — vandaar los toegevoegd i.p.v. in detail van een
  // storm-signaal.
  return [...stormSignalen, ...outlookSignalen];
}
