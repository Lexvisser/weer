// Lifeliner — de Nederlandse traumahelikopters (MMT, Mobiel Medisch Team).
// Dit zijn GEEN P2000-tekstberichten (zie sources/p2000.js voor brandweer/
// politie/ambulance) maar live vluchtdata: we volgen de bekende registraties
// via OpenSky Network, een gratis/geen-sleutel ADS-B-vluchtdatabase
// (opensky-network.org, non-profit/community-onderhouden sensor-netwerk).
//
// Bekende registraties (bron: traumaradar.nl, 2026-08-19 — NIET onafhankelijk
// live geverifieerd tegen een echte vlucht, dus kan achterhaald/onvolledig
// zijn als een helikopter van tail-nummer wisselt):
//   Lifeliner 1 — Amsterdam Heliport     — PH-TTR
//   Lifeliner 2 — Rotterdam The Hague    — PH-MAA
//   Lifeliner 3 — Vliegbasis Volkel      — PH-UMC
//   Lifeliner 4 — Groningen Airport Eelde— PH-HVB
//   Ambulancehelikopter Leeuwarden       — PH-OOP (niet officieel "Lifeliner"
//     genummerd, maar zelfde soort inzet — wel meegenomen op Lex' verzoek
//     ("brandweer, politie, ambulance, lifeliner" — dit valt onder ambulance-
//     lucht).
//
// OpenSky's `callsign`-veld is bij kleine toestellen vaak leeg of bevat de
// registratie zelf (spaties opgevuld tot 8 tekens) i.p.v. een nette
// vluchtnaam als "LIFELN1" — we matchen daarom op BEIDE: een eventuele
// LIFELN-callsign EN de bekende registratie (spaties/streepjes genegeerd).
//
// EERLIJKE WAARSCHUWING: nooit live getest (geen internettoegang in de
// sandbox waar dit gebouwd is) — het matchen op registratie in het
// callsign-veld is een aanname over hoe OpenSky dit specifieke type toestel
// rapporteert. Bij opstarten loggen we de eerste poll met hoeveel toestellen
// er in de bounding box zaten en hoeveel daarvan matchten, zodat op je eigen
// PC meteen te zien is of de match iets oplevert.
import { makeSignal, afstandKm } from '../normalize.js';

const STATES_URL = 'https://opensky-network.org/api/states/all';

// ---- Gevlogen route bijhouden, 2026-08-19 ----------------------------------
// OpenSky's states/all geeft alleen een momentopname, geen geschiedenis — de
// "echte" trackgeschiedenis-endpoint (/tracks) bestaat wel bij OpenSky, maar
// vereist een OAuth2-account (geen anonieme toegang), dus bewust niet
// gebruikt om dit sleutelloos te houden zoals de rest van het project. In
// plaats daarvan bouwen we zelf een spoor op: elke poll die een toestel nog
// in de lucht ziet, plakken we het huidige punt achter een lijst met eerdere
// punten voor datzelfde icao24 (module-brede Map, overleeft dus pollcycli).
// Wordt vanzelf ruwer/grover naarmate het poll-interval groter is — vandaar
// dat lifeliner (i.t.t. de meeste andere bronnen) een kort interval heeft
// (zie config.js), specifiek om een bruikbaar spoor te krijgen.
const TRAIL_VENSTER_MS = 90 * 60 * 1000; // hoe lang geleden een punt nog meetelt (dekt een enkele vlucht heen+terug)
const TRAIL_STALE_MS = 20 * 60 * 1000; // zo lang niet meer gezien = spoor wissen (nieuwe vlucht begint vers)
const TRAIL_MAX_PUNTEN = 60; // extra vangnet naast het tijdvenster
const trails = new Map(); // icao24 -> { punten: [{lat,lon,tijdMs}], laatstGezienMs }

// "Alleen bij mij in de buurt" — ruimer dan de P2000-straal (25km) omdat een
// helikopter die net over de horizon vliegt ook nog relevant/zichtbaar is,
// en omdat je toch al alleen toestellen ziet die daadwerkelijk static hierin
// vliegen (geen ruis zoals bij tekst-gebaseerde bronnen).
const STRAAL_KM = 75;

const BEKENDE_REGISTRATIES = new Map([
  ['PHTTR', 'Lifeliner 1'],
  ['PHMAA', 'Lifeliner 2'],
  ['PHUMC', 'Lifeliner 3'],
  ['PHHVB', 'Lifeliner 4'],
  ['PHOOP', 'Ambulancehelikopter Leeuwarden'],
]);

function normaliseer(str) {
  return String(str ?? '').replace(/[\s-]/g, '').toUpperCase();
}

function naamVoor(icao24, callsign) {
  const kaleCallsign = normaliseer(callsign);
  if (kaleCallsign.startsWith('LIFELN')) return `Lifeliner ${kaleCallsign.replace('LIFELN', '') || '?'}`;
  for (const [reg, naam] of BEKENDE_REGISTRATIES) {
    if (kaleCallsign === reg) return naam;
  }
  return null;
}

// ---- Kompasrichting i.p.v. een echte bestemming, 2026-08-19 ----------------
// Lex vroeg waar de Lifeliner "naar toe gaat" — net als P2000 nu de echte
// straat/plaats laat zien i.p.v. een kaal bonnummer. Bij Lifeliner ligt dat
// anders: OpenSky (gratis/sleutelloos ADS-B) geeft alléén live positie +
// koers, GEEN vluchtplan/bestemming — dat bestaat simpelweg niet in deze
// databron (een vluchtplan zit bij de luchtverkeersleiding, niet bij ADS-B-
// ontvangststations). Een "bestemming" verzinnen zou dus gokwerk zijn.
// Eerlijker alternatief: de vliegrichting zelf, afgeleid uit het al
// opgehaalde `koersGraden`-veld, omgezet naar een herkenbare kompas-
// afkorting (16-punts, zoals op een scheepskompas/windroos). Geen bestemming,
// wel een bruikbare aanwijzing van "waar naartoe" — en, i.t.t. een gegokte
// bestemming, 100% traceerbaar naar de ruwe data.
const KOMPASPUNTEN = ['N', 'NNO', 'NO', 'ONO', 'O', 'OZO', 'ZO', 'ZZO', 'Z', 'ZZW', 'ZW', 'WZW', 'W', 'WNW', 'NW', 'NNW'];

function graadNaarKompas(graden) {
  if (graden == null || Number.isNaN(graden)) return null;
  const index = Math.round(((graden % 360) + 360) % 360 / 22.5) % 16;
  return KOMPASPUNTEN[index];
}

// Grove bounding box rond thuis — 1° breedtegraad ≈ 111km overal, 1°
// lengtegraad ≈ 111km × cos(breedtegraad), dus gecorrigeerd voor NL's
// breedtegraad zodat de box ongeveer vierkant blijft i.p.v. te breed te zijn.
function boundingBox(lat, lon, straalKm) {
  const dLat = straalKm / 111;
  const dLon = straalKm / (111 * Math.cos((lat * Math.PI) / 180));
  return { lamin: lat - dLat, lamax: lat + dLat, lomin: lon - dLon, lomax: lon + dLon };
}

export async function fetchLifeliner({ homeLat, homeLon }) {
  if (homeLat == null || homeLon == null) return [];
  const { lamin, lamax, lomin, lomax } = boundingBox(homeLat, homeLon, STRAAL_KM);

  const url = `${STATES_URL}?lamin=${lamin}&lomin=${lomin}&lamax=${lamax}&lomax=${lomax}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`OpenSky states/all gaf status ${res.status}`);
  const body = await res.json();
  const states = body.states ?? [];

  let matches = 0;
  const nu = Date.now();
  const gezienDezeRonde = new Set();
  const signalen = [];
  for (const s of states) {
    const [icao24, callsignRuw, , , , lon, lat, baroAltM, aanGrond, snelheidMs, koersGraden] = s;
    const naam = naamVoor(icao24, callsignRuw);
    if (!naam) continue;
    if (lat == null || lon == null) continue; // geen positie bekend (net geland/net vertrokken)

    matches++;
    gezienDezeRonde.add(icao24);

    // Spoor bijwerken — alleen punten toevoegen als 'ie echt vliegt (aan de
    // grond kan hij stilstaan/taxiën, dat hoort niet bij de vluchtroute).
    let trail = trails.get(icao24);
    if (!trail) {
      trail = { punten: [], laatstGezienMs: nu };
      trails.set(icao24, trail);
    }
    trail.laatstGezienMs = nu;
    if (!aanGrond) {
      trail.punten.push({ lat, lon, tijdMs: nu });
      trail.punten = trail.punten
        .filter((p) => nu - p.tijdMs <= TRAIL_VENSTER_MS)
        .slice(-TRAIL_MAX_PUNTEN);
    }

    const afstand = afstandKm(homeLat, homeLon, lat, lon);
    // Kompasrichting alleen tonen als 'ie ook echt vliegt — aan de grond
    // (stilstaand/taxiend) is een "koers" niet zinvol en vaak ruis.
    const kompas = !aanGrond ? graadNaarKompas(koersGraden) : null;
    signalen.push(
      makeSignal({
        id: `lifeliner-${icao24}`,
        categorie: 'hulpdiensten',
        // "Categorie - kort" patroon (2026-08-19), zelfde als bij p2000.js —
        // consistent met de rest van de Meldingenlijst. Kompasrichting erbij
        // (2026-08-19, op verzoek van Lex: "waar ie naar toe gaat") — géén
        // echte bestemming (OpenSky levert geen vluchtplan), wel een
        // eerlijke, uit de live koers afgeleide aanwijzing.
        titel: `Hulpdiensten - ${naam}${kompas ? ` (koers ${kompas})` : ''}`,
        ernst: 'waarschuwing', // een traumahelikopter in de lucht duidt vrijwel altijd op een actieve inzet
        lat,
        lon,
        tijd: new Date().toISOString(),
        detail: {
          discipline: 'lifeliner',
          naam,
          icao24,
          aanGrond: Boolean(aanGrond),
          hoogteM: baroAltM != null ? Math.round(baroAltM) : null,
          snelheidKmh: snelheidMs != null ? Math.round(snelheidMs * 3.6) : null,
          koersGraden: koersGraden != null ? Math.round(koersGraden) : null,
          kompas,
          afstandTotJouKm: afstand,
          subtitel: `${afstand} km van huis${kompas ? ` · koers ${kompas}` : ''}${baroAltM != null ? ` · ${Math.round(baroAltM)} m hoogte` : ''}`,
          bronUrl: 'https://opensky-network.org/',
          // Route tot nu toe (sinds deze poll-loop 'm is gaan volgen — geen
          // historische data van vóór het opstarten van de backend), oud
          // naar nieuw, klaar voor Leaflet's L.polyline([[lat,lon], ...]).
          route: trail.punten.map((p) => [p.lat, p.lon]),
        },
      }),
    );
  }

  // Sporen van toestellen die deze ronde niet meer voorkwamen (geland/buiten
  // bereik) een tijdje bewaren i.p.v. meteen weggooien — pas na
  // TRAIL_STALE_MS opruimen, zodat een kort gat in de dekking niet meteen de
  // hele route laat verdwijnen. Wél nodig: anders groeit deze Map ongelimiteerd.
  for (const [icao24, trail] of trails) {
    if (!gezienDezeRonde.has(icao24) && nu - trail.laatstGezienMs > TRAIL_STALE_MS) {
      trails.delete(icao24);
    }
  }

  console.log(`[weer] lifeliner: ${states.length} toestel(len) in de bounding box, ${matches} match(en)`);
  return signalen;
}
