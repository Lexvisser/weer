// Meteorenzwermen — geen live API, dit zijn jaarlijks vrijwel vaste
// kalenderdata (IMO-jaaroverzicht, 1x per jaar handmatig te controleren).
// Puur lokale berekening, zelfde aanpak als moon.js: alleen een signaal
// zodra we ons daadwerkelijk in het actieve venster van een zwerm bevinden,
// en stil de rest van het jaar — geen educatieve "altijd zichtbare" tegel.
import { makeSignal } from '../normalize.js';

// [maand, dag], 1-geïndexeerd. "van"/"tot" mag het jaar doorkruisen
// (bijv. Quadrantiden: eind december t/m half januari).
const ZWERMEN = [
  { naam: 'Quadrantiden', van: [12, 28], piek: [1, 3], tot: [1, 12], zhr: 120 },
  { naam: 'Lyriden', van: [4, 16], piek: [4, 22], tot: [4, 25], zhr: 18 },
  { naam: 'Eta Aquariden', van: [4, 19], piek: [5, 5], tot: [5, 28], zhr: 50 },
  { naam: 'Perseïden', van: [7, 17], piek: [8, 12], tot: [8, 24], zhr: 100 },
  { naam: 'Orioniden', van: [10, 2], piek: [10, 21], tot: [11, 7], zhr: 20 },
  { naam: 'Leoniden', van: [11, 6], piek: [11, 17], tot: [11, 30], zhr: 15 },
  { naam: 'Geminiden', van: [12, 4], piek: [12, 14], tot: [12, 17], zhr: 150 },
  { naam: 'Ursiden', van: [12, 17], piek: [12, 22], tot: [12, 26], zhr: 10 },
];

function ordinaal(maand, dag, jaar) {
  return Date.UTC(jaar, maand - 1, dag);
}

function binnenVenster(nuTs, jaar, van, tot) {
  const vanTs = ordinaal(van[0], van[1], jaar);
  const totTs = ordinaal(tot[0], tot[1], jaar);
  if (vanTs <= totTs) return nuTs >= vanTs && nuTs <= totTs;
  return nuTs >= vanTs || nuTs <= totTs; // venster doorkruist de jaarwisseling
}

function dichtstbijzijndePiek(nuTs, jaar, piek) {
  const kandidaten = [jaar - 1, jaar, jaar + 1].map((j) => ordinaal(piek[0], piek[1], j));
  return kandidaten.reduce((beste, t) => (Math.abs(t - nuTs) < Math.abs(beste - nuTs) ? t : beste));
}

export async function fetchMeteors() {
  const nu = new Date();
  const jaar = nu.getUTCFullYear();
  const nuTs = Date.UTC(jaar, nu.getUTCMonth(), nu.getUTCDate());
  const signalen = [];

  for (const zwerm of ZWERMEN) {
    if (!binnenVenster(nuTs, jaar, zwerm.van, zwerm.tot)) continue;

    const piekTs = dichtstbijzijndePiek(nuTs, jaar, zwerm.piek);
    const dagenTotPiek = Math.round((piekTs - nuTs) / (24 * 60 * 60 * 1000));
    const opPiek = Math.abs(dagenTotPiek) <= 1;

    signalen.push(
      makeSignal({
        id: `meteors-${zwerm.naam.toLowerCase().replace(/\s+/g, '-')}`,
        categorie: 'hemel',
        titel: opPiek
          ? `${zwerm.naam} vannacht op zijn piek`
          : dagenTotPiek > 0
            ? `${zwerm.naam} actief (piek over ${dagenTotPiek} dagen)`
            : `${zwerm.naam} actief (piek was ${Math.abs(dagenTotPiek)} dagen geleden)`,
        ernst: opPiek ? 'let-op' : 'info',
        tijd: nu.toISOString(),
        detail: {
          zhrPerUur: zwerm.zhr,
          pieknacht: opPiek,
        },
      }),
    );
  }

  return signalen;
}
