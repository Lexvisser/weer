// NWS — api.weather.gov actieve tornado-waarschuwingen én -watches. Officieel,
// gratis, geen sleutel nodig — wel verplicht een herkenbare User-Agent header
// mee te sturen (staat in NWS' API-etiquette). Documentatie:
// https://www.weather.gov/documentation/services-web-api
//
// Let op: dekt uitsluitend de Verenigde Staten (NWS heeft geen mandaat
// elders) — dit is dus de VS-tegenhanger van "tornado", niet wereldwijd.
// Geometrie in de API is een polygon (of soms null), geen los punt; we
// berekenen zelf het zwaartepunt van de polygon voor de kaartpin, én sturen
// de volledige polygon mee (detail.gebiedPolygon) zodat de frontend 'm als
// omtrek kan tekenen zodra iemand de melding aantikt.
//
// Tornado Warning (imminent, klein gebied, van het lokale NWS-kantoor) en
// Tornado Watch (preventief, groot gebied — vaak een hele "watch box" van
// meerdere staten, uitgegeven door het Storm Prediction Center) zijn bewust
// twee aparte categorieën: heel ander karakter (nu vs. "houd dit gebied in
// de gaten"), dus ook een andere ernst-inschatting en een andere manier van
// tonen op de kaart (warning: gewone hazard-pin; watch: pin + polygon-omtrek).
import { makeSignal } from '../normalize.js';

const EVENT_TYPES = [
  { event: 'Tornado Warning', categorie: 'tornado' },
  { event: 'Tornado Watch', categorie: 'tornado-watch' },
];

const ERNST_PER_SEVERITY = { Extreme: 'kritiek', Severe: 'waarschuwing', Moderate: 'let-op', Minor: 'info' };

function ernstVoor(categorie, severity) {
  const basis = ERNST_PER_SEVERITY[severity] ?? (categorie === 'tornado-watch' ? 'let-op' : 'waarschuwing');
  // Een "watch" is preventief — nooit zo dringend als een actieve warning,
  // ook niet als NWS 'm zelf als "Extreme" classificeert.
  if (categorie === 'tornado-watch' && basis === 'kritiek') return 'waarschuwing';
  return basis;
}

function ringen(geometry) {
  if (!geometry) return [];
  if (geometry.type === 'Polygon') return [geometry.coordinates[0]];
  if (geometry.type === 'MultiPolygon') return geometry.coordinates.map((polygon) => polygon[0]);
  return [];
}

function zwaartepunt(geometry) {
  const punten = ringen(geometry).flat();
  if (!punten.length) return [null, null];
  const lon = punten.reduce((som, p) => som + p[0], 0) / punten.length;
  const lat = punten.reduce((som, p) => som + p[1], 0) / punten.length;
  return [lat, lon];
}

// GeoJSON-ringen zijn [lon, lat] — Leaflet wil [lat, lon].
function ringenAlsLatLon(geometry) {
  return ringen(geometry).map((ring) => ring.map(([lon, lat]) => [lat, lon]));
}

async function fetchEventType({ event, categorie }) {
  const res = await fetch(`https://api.weather.gov/alerts/active?event=${encodeURIComponent(event)}`, {
    headers: {
      'User-Agent': 'weer-app-persoonlijk (contact: lokaal project)',
      Accept: 'application/geo+json',
    },
  });
  if (!res.ok) throw new Error(`NWS feed (${event}) gaf status ${res.status}`);
  const body = await res.json();

  return (body.features ?? []).map((f) => {
    const p = f.properties;
    const [lat, lon] = zwaartepunt(f.geometry);
    const gebiedPolygon = ringenAlsLatLon(f.geometry);
    return makeSignal({
      id: `nws-${p.id}`,
      categorie,
      titel: p.headline ?? p.event ?? event,
      ernst: ernstVoor(categorie, p.severity),
      lat,
      lon,
      tijd: p.effective ?? p.sent,
      detail: {
        gebied: p.areaDesc ?? null,
        geldigTot: p.expires ?? null,
        instructie: p.instruction ?? null,
        bronUrl: 'https://alerts.weather.gov/',
        gebiedPolygon: gebiedPolygon.length ? gebiedPolygon : null,
      },
    });
  });
}

// ---- Testfixture: gesimuleerde watch om de gebied-omtrek-weergave te
// bekijken zonder te wachten op een echte actieve VS-tornado-watch. Alleen
// actief met WEER_TEST_TORNADO_WATCH=1 in backend/.env — zet 'm daarna weer
// terug naar 0 (of verwijder de regel) en herstart, anders blijft er
// permanent een nep-melding tussen de echte data staan. Titel is expres
// onmiskenbaar als "TEST" gemarkeerd, precies omdat het hele punt van deze
// app eerlijke, vertrouwde signalering is — een nep-alarm mag nooit op een
// echte lijken.
function testTornadoWatchSignaal() {
  const nu = Date.now();
  // Ruwe, plausibele "watch box"-vorm over Kansas/Oklahoma (klassiek Tornado
  // Alley-gebied) — geen echte NWS-coördinaten, puur om de polygon-tekening
  // en fitBounds-gedrag te kunnen bekijken.
  const gebiedPolygon = [
    [
      [37.6, -99.4],
      [37.9, -96.0],
      [34.1, -95.2],
      [33.8, -98.6],
      [37.6, -99.4],
    ],
  ];
  const [lat, lon] = [35.85, -97.3];
  return makeSignal({
    id: 'nws-test-tornado-watch',
    categorie: 'tornado-watch',
    titel: 'TEST — Tornado Watch (gesimuleerd, geen echt alarm)',
    ernst: 'waarschuwing',
    lat,
    lon,
    tijd: new Date(nu).toISOString(),
    detail: {
      gebied: 'TEST-gebied — Kansas/Oklahoma (gesimuleerd)',
      geldigTot: new Date(nu + 3 * 60 * 60 * 1000).toISOString(),
      instructie: null,
      bronUrl: 'https://alerts.weather.gov/',
      gebiedPolygon,
    },
  });
}

export async function fetchNws() {
  // Beide event-types los ophalen i.p.v. één gecombineerde query — als één
  // van de twee hapert, valt de hele bron niet meteen stil (bv. alleen
  // warnings tonen als watches tijdelijk mislukken is beter dan niets).
  const resultaten = await Promise.allSettled(EVENT_TYPES.map(fetchEventType));
  const gelukt = resultaten.filter((r) => r.status === 'fulfilled');
  if (!gelukt.length) throw resultaten[0].reason;
  resultaten
    .filter((r) => r.status === 'rejected')
    .forEach((r) => console.error('[weer] nws: één event-type mislukte,', r.reason?.message ?? r.reason));
  const signalen = gelukt.flatMap((r) => r.value);
  if (process.env.WEER_TEST_TORNADO_WATCH === '1') {
    console.log('[weer] nws: WEER_TEST_TORNADO_WATCH=1 — gesimuleerde tornado-watch toegevoegd (niet echt!)');
    signalen.push(testTornadoWatchSignaal());
  }
  return signalen;
}
