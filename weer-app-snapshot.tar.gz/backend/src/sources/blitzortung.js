// Blitzortung.org — bliksem/onweer, via de live-kaart-WebSocket. GEEN
// officiële REST-API, geen documentatie, geen SLA — reverse-engineered
// community-kennis (o.a. terug te vinden in verschillende doe-het-zelf
// write-ups en de Home Assistant "blitzortung"-custom-component van mrk-its).
//
// EERLIJKE WAARSCHUWING: de exacte byte-voor-byte decodering hieronder is
// nooit live getest door degene die dit geschreven heeft — de omgeving waarin
// dit gebouwd is heeft geen uitgaande WebSocket-toegang. Bij het opstarten
// loggen we de eerste paar ruwe/gedecodeerde berichten naar de console
// (zoek naar "[weer] blitzortung: voorbeeldrecord") — check die eventjes op
// je eigen PC. Zien ze eruit als {lat, lon, time, ...}? Dan werkt het. Zie je
// alleen troep of helemaal niets? Dan is het protocol veranderd en moet
// decompress()/SUBSCRIBE_BERICHT bijgesteld worden — de rest van dit bestand
// (clustering, naderend/actief-bepaling) is onafhankelijk daarvan en blijft
// gewoon werken zodra de decodering weer klopt.
//
// Architectuur wijkt bewust af van de andere bronnen: dit is een permanente
// streaming-verbinding i.p.v. periodiek pollen (vandaar pollIntervalMs: null
// in config.js) — server.js start 'm één keer bij opstarten via
// startBlitzortungStream(), niet via de gewone poll-lus.
import { makeSignal, afstandKm } from '../normalize.js';

const WS_HOSTS = ['ws1.blitzortung.org', 'ws7.blitzortung.org', 'ws8.blitzortung.org'];
const SUBSCRIBE_BERICHT = '{"a":111}'; // magic subscribe-bericht na het openen van de verbinding

// Bewust ruim gezet: bij 300km bleef de kaart vaak helemaal leeg (geen
// onweer zo dicht bij huis), terwijl onweer ergens over Frankrijk/Duitsland/
// Centraal-Europa ook prima het bekijken waard is. Eerst op 900km gezet,
// maar bleek in de praktijk (2026-08-17, via HA-vergelijking) nog te krap:
// gewoon onweer boven Slovenië/Italië (~970-1270km) viel er al buiten,
// waardoor de kaart vaker leeg was dan zinvol. Op verzoek van Lex ("zet die
// straal lekker ruim 2000 km of zo wat geeft het") verruimd naar 2000km —
// dekt daarmee ook Zuid-Europa/Noord-Afrika/Turkije/West-Rusland.
const STRAAL_KM = 2000; // flitsen verder weg dan dit negeren we meteen (geheugen + relevantie)
const VENSTER_MS = 30 * 60 * 1000; // hoeveel geschiedenis we bewaren voor clustering
const HERBEREKEN_MS = 60 * 1000; // hoe vaak we complexen herberekenen en publiceren
const CLUSTER_AFSTAND_KM = 40; // flitsen binnen deze afstand van elkaar horen bij hetzelfde complex
const MIN_FLITSEN_VOOR_COMPLEX = 3; // ruis (losse verdwaalde flitsen) wegfilteren
const ACTIEF_AFSTAND_KM = 25; // binnen deze afstand van thuis geldt een complex als "actief"
const NADEREND_DREMPEL_KM = 3; // moet minstens dit dichterbij zijn gekomen om als "naderend" te tellen

// ---- Decompressie van de geobfusceerde websocket-payload ------------------
// Homebrew LZW-achig schema: elk binnenkomend teken is óf een letterlijk
// teken (code < 256) óf een terugverwijzing naar een eerder opgebouwd
// "woord" uit een groeiend woordenboek. Zie het protocol-voorbehoud hierboven.
function decompress(data) {
  const woordenboek = {};
  let vorig = data[0];
  let resultaat = vorig;
  let volgendeCode = 256;
  for (let i = 1; i < data.length; i++) {
    const teken = data[i];
    const code = teken.charCodeAt(0);
    const woord = code < 256 ? teken : (woordenboek[code] ?? vorig + vorig[0]);
    resultaat += woord;
    woordenboek[volgendeCode] = vorig + woord[0];
    volgendeCode++;
    vorig = woord;
  }
  return resultaat;
}

function decodeBericht(ruw) {
  return JSON.parse(decompress(ruw));
}

// ---- Eén WebSocket-verbinding opzetten -------------------------------------
function verbind(host, { onOpen, onRecord, onClose, onDecodeerfout }) {
  const ws = new WebSocket(`wss://${host}/`);
  ws.addEventListener('open', () => {
    onOpen();
    ws.send(SUBSCRIBE_BERICHT);
  });
  ws.addEventListener('message', (ev) => {
    try {
      onRecord(decodeBericht(String(ev.data)));
    } catch (err) {
      onDecodeerfout(err);
    }
  });
  ws.addEventListener('close', onClose);
  ws.addEventListener('error', () => {}); // 'close' volgt hier altijd op, daar herstellen we
  return ws;
}

// ---- Clustering: losse flitsen groeperen tot "complexen" ------------------
// Bewust simpel/greedy (geen echte spatiale clustering zoals DBSCAN) — een
// nieuwe flits sluit aan bij het dichtstbijzijnde bestaande cluster (op basis
// van de laatst toegevoegde flits daarin) als die binnen CLUSTER_AFSTAND_KM
// ligt, anders begint een nieuw cluster. Elke hereken-cyclus (elke minuut)
// wordt dit vers opnieuw berekend over het hele venster, dus fouten stapelen
// niet op — voor typische onweerscellen (tientallen km groot) werkt dit
// prima als eerste versie; kan later verfijnd worden als het te grof blijkt.
function clusterFlitsen(flitsen) {
  const clusters = [];
  for (const f of flitsen) {
    const doel = clusters.find((c) => afstandKm(c.laatsteLat, c.laatsteLon, f.lat, f.lon) <= CLUSTER_AFSTAND_KM);
    if (doel) {
      doel.flitsen.push(f);
      doel.laatsteLat = f.lat;
      doel.laatsteLon = f.lon;
    } else {
      clusters.push({ laatsteLat: f.lat, laatsteLon: f.lon, flitsen: [f] });
    }
  }
  return clusters.filter((c) => c.flitsen.length >= MIN_FLITSEN_VOOR_COMPLEX);
}

function centroid(flitsen) {
  return {
    lat: flitsen.reduce((s, f) => s + f.lat, 0) / flitsen.length,
    lon: flitsen.reduce((s, f) => s + f.lon, 0) / flitsen.length,
  };
}

// ---- Per cluster: is het naderend, actief, of trekt het weg? --------------
function bouwSignalen(clusters, homeLat, homeLon, nu) {
  return clusters.map((c) => {
    const recent = c.flitsen.filter((f) => nu - f.tijdMs <= 5 * 60 * 1000);
    const ouder = c.flitsen.filter((f) => nu - f.tijdMs > 10 * 60 * 1000 && nu - f.tijdMs <= 25 * 60 * 1000);
    const puntNu = centroid(recent.length ? recent : c.flitsen);
    const afstandNu = afstandKm(homeLat, homeLon, puntNu.lat, puntNu.lon);

    let status = 'stabiel';
    if (afstandNu <= ACTIEF_AFSTAND_KM) {
      status = 'actief';
    } else if (ouder.length >= MIN_FLITSEN_VOOR_COMPLEX) {
      const afstandOuder = afstandKm(homeLat, homeLon, centroid(ouder).lat, centroid(ouder).lon);
      if (afstandOuder - afstandNu >= NADEREND_DREMPEL_KM) status = 'naderend';
      else if (afstandNu - afstandOuder >= NADEREND_DREMPEL_KM) status = 'verwijderend';
    } else {
      status = 'onbekend'; // te weinig historie om een richting te bepalen
    }

    const ernst =
      status === 'actief' ? 'kritiek' : status === 'naderend' && afstandNu < 100 ? 'waarschuwing' : status === 'naderend' ? 'let-op' : 'info';

    const titel =
      status === 'actief'
        ? `Onweercomplex boven je (${c.flitsen.length} flitsen/30 min)`
        : status === 'naderend'
          ? `Onweercomplex nadert — nog ${afstandNu} km`
          : status === 'verwijderend'
            ? `Onweercomplex trekt weg — ${afstandNu} km`
            : `Onweercomplex op ${afstandNu} km`;

    // Grofmazige maar stabiele id (afgerond op ~0,5°) zodat hetzelfde complex
    // niet elke minuut een compleet nieuwe id krijgt zolang het ~ter plekke blijft.
    const idLat = Math.round(puntNu.lat / 0.5) * 0.5;
    const idLon = Math.round(puntNu.lon / 0.5) * 0.5;

    return makeSignal({
      id: `blitzortung-complex-${idLat}-${idLon}`,
      categorie: 'onweercomplex',
      titel,
      ernst,
      lat: puntNu.lat,
      lon: puntNu.lon,
      tijd: new Date(nu).toISOString(),
      detail: {
        status,
        afstandKm: afstandNu,
        aantalFlitsenLaatsteHalfUur: c.flitsen.length,
        subtitel: `${c.flitsen.length} flitsen laatste 30 min · ${afstandNu} km van huis`,
        bronUrl: 'https://www.blitzortung.org/',
        // Individuele flitsen (afgerond, alleen lat/lon/leeftijd) zodat de
        // frontend ze kan tonen zodra iemand dit complex aantikt — puur
        // fijnmazige visualisatie, niet nodig voor de complex-marker zelf.
        flitsen: c.flitsen.map((f) => ({
          lat: Math.round(f.lat * 1000) / 1000,
          lon: Math.round(f.lon * 1000) / 1000,
          secondenGeleden: Math.round((nu - f.tijdMs) / 1000),
        })),
      },
    });
  });
}

export function startBlitzortungStream({ homeLat, homeLon, onUpdate, onError }) {
  if (typeof WebSocket === 'undefined') {
    onError(new Error('Deze Node-versie heeft geen ingebouwde WebSocket (nodig: Node 22+).'));
    return () => {};
  }

  let flitsen = []; // { lat, lon, tijdMs }
  let hostIndex = 0;
  let backoffMs = 5000;
  let gestopt = false;
  let verbonden = false;
  let ws = null;
  let herverbindTimer = null;
  let voorbeeldenGelogd = 0;
  // Tellers puur voor zichtbaarheid in de console — zonder dit is er geen
  // manier om van buitenaf te zien of de WebSocket nog echt data ontvangt
  // (verwerkRecord zwijgt normaal na de eerste 3 voorbeeldregels), wat het
  // lastig maakt te onderscheiden tussen "verbinding is stil" en "er is
  // gewoon even geen onweer binnen bereik".
  let ontvangenSindsVorige = 0;
  let binnenBereikSindsVorige = 0;
  const herbereekTimer = setInterval(opschonenEnPublicerenLoop, HERBEREKEN_MS);

  function log(bericht) {
    console.log(`[weer] blitzortung: ${bericht}`);
  }

  function verwerkRecord(record) {
    if (voorbeeldenGelogd < 3) {
      voorbeeldenGelogd++;
      log(`voorbeeldrecord ${voorbeeldenGelogd}: ${JSON.stringify(record).slice(0, 200)}`);
    }
    ontvangenSindsVorige++;
    if (typeof record?.lat !== 'number' || typeof record?.lon !== 'number') return;
    const afstand = afstandKm(homeLat, homeLon, record.lat, record.lon);
    if (afstand > STRAAL_KM) return;
    binnenBereikSindsVorige++;
    // 'time' komt bij Blitzortung binnen als nanoseconden-sinds-epoch.
    const tijdMs = record.time ? Math.round(record.time / 1e6) : Date.now();
    flitsen.push({ lat: record.lat, lon: record.lon, tijdMs });
  }

  function opschonenEnPublicerenLoop() {
    const nu = Date.now();
    flitsen = flitsen.filter((f) => nu - f.tijdMs <= VENSTER_MS);
    // Elke minuut een statusregel — laat objectief zien of de stream nog
    // binnenkomt (ontvangen>0) en hoeveel daarvan binnen de 900km-straal valt,
    // los van of dat toevallig genoeg is voor een complex (min. 3 flitsen/40km).
    log(
      `status: ${ontvangenSindsVorige} bericht(en) ontvangen laatste minuut, ` +
        `${binnenBereikSindsVorige} daarvan binnen ${STRAAL_KM}km, ` +
        `${flitsen.length} flitsen totaal in het 30-min-venster`
    );
    ontvangenSindsVorige = 0;
    binnenBereikSindsVorige = 0;
    if (!verbonden) {
      onError(new Error('geen actieve Blitzortung-verbinding'));
      return;
    }
    const clusters = clusterFlitsen(flitsen);
    if (clusters.length) {
      log(`${clusters.length} complex(en) gevonden: ${clusters.map((c) => c.flitsen.length).join(', ')} flitsen elk`);
    }
    const signalen = bouwSignalen(clusters, homeLat, homeLon, nu);
    onUpdate(signalen);
  }

  function planHerverbinding() {
    verbonden = false;
    if (gestopt) return;
    herverbindTimer = setTimeout(() => {
      hostIndex = (hostIndex + 1) % WS_HOSTS.length;
      verbindOpnieuw();
    }, backoffMs);
    backoffMs = Math.min(backoffMs * 2, 2 * 60 * 1000);
  }

  function verbindOpnieuw() {
    if (gestopt) return;
    const host = WS_HOSTS[hostIndex];
    try {
      ws = verbind(host, {
        onOpen: () => {
          verbonden = true;
          backoffMs = 5000;
          log(`verbonden met ${host}`);
        },
        onRecord: verwerkRecord,
        onDecodeerfout: (err) => log(`kon bericht niet decoderen (${host}): ${err.message}`),
        onClose: () => {
          log(`verbinding met ${host} gesloten, nieuwe poging over ${Math.round(backoffMs / 1000)}s`);
          planHerverbinding();
        },
      });
    } catch (err) {
      log(`kon niet verbinden met ${host}: ${err.message}`);
      planHerverbinding();
    }
  }

  verbindOpnieuw();

  return function stop() {
    gestopt = true;
    clearInterval(herbereekTimer);
    clearTimeout(herverbindTimer);
    if (ws) ws.close();
  };
}
