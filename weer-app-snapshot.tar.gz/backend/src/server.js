// Bewust zonder externe dependencies (express etc.) — dit hele project draait
// puur op Node zelf. Dat betekent: geen "npm install" nodig om te starten,
// gewoon "node src/index.js". Scheelt gedoe voor een klein persoonlijk project.
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { join, extname } from 'node:path';
import { SOURCES } from './config.js';
import { SourceState } from './normalize.js';

import { fetchUsgs } from './sources/usgs.js';
import { fetchMoon } from './sources/moon.js';
import { fetchNhc } from './sources/nhc.js';
import { fetchEmsc } from './sources/emsc.js';
import { fetchNws } from './sources/nws.js';
import { fetchOpenMeteo } from './sources/openmeteo.js';
import { fetchKnmi } from './sources/knmi.js';
import { fetchMeteoalarm } from './sources/meteoalarm.js';
import { fetchGdacs } from './sources/gdacs.js';
import { startBlitzortungStream } from './sources/blitzortung.js';
import { fetchCelestrak } from './sources/celestrak.js';
import { fetchSwpc } from './sources/swpc.js';
import { fetchDonki } from './sources/donki.js';
import { fetchMeteors } from './sources/meteors.js';
import { fetchSpcOutlook } from './sources/spcOutlook.js';
import { fetchIemLsr } from './sources/iemLsr.js';
import { fetchNexradStations } from './sources/nexradStations.js';
import { fetchP2000, msSindsLaatsteMMTMelding } from './sources/p2000.js';
import { fetchLifeliner } from './sources/lifeliner.js';

// Elke bron-id (uit config.js) gekoppeld aan de functie die 'm ophaalt.
// Nieuwe bron toevoegen? Zet 'm hier neer, voeg een rij toe in config.js,
// en klaar — de rest (polling, caching, /api/signals, /api/status) werkt vanzelf.
// Uitzondering: 'blitzortung' staat hier bewust NIET in — dat is een
// permanente streaming-verbinding (zie startPolling hieronder), geen
// periodieke fetch-functie zoals de rest.
const FETCHERS = {
  usgs: (env) => fetchUsgs(env),
  moon: () => fetchMoon(),
  nhc: () => fetchNhc(),
  emsc: (env) => fetchEmsc(env),
  nws: () => fetchNws(),
  openmeteo: (env) => fetchOpenMeteo(env),
  knmi: (env) => fetchKnmi(env),
  meteoalarm: () => fetchMeteoalarm(),
  gdacs: () => fetchGdacs(),
  celestrak: (env) => fetchCelestrak(env),
  swpc: (env) => fetchSwpc(env),
  donki: (env) => fetchDonki(env),
  meteors: () => fetchMeteors(),
  spcOutlook: () => fetchSpcOutlook(),
  iemLsr: () => fetchIemLsr(),
  p2000: (env) => fetchP2000(env),
  lifeliner: (env) => fetchLifeliner(env),
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*', // gemakkelijk binnen je eigen tailnet, geen publieke blootstelling
  });
  res.end(body);
}

// ---- Kaarttegel-proxy, 2026-08-19 ------------------------------------------
// Waarom: Lex zag op zijn eigen scherm herhaaldelijk een ingebakken
// "Zoom Level Not Supported"-plaatje (HTTP 200, dus geen netwerkfout) — eerst
// bij CARTO's dark_all, daarna bij Esri's World_Dark_Gray_Base, daarna ook bij
// Esri's World_Dark_Gray_Reference, en zelfs toen de backend zelf (server-side,
// dus los van Lex' browser/netwerk/service-worker) de tegel ophaalde bleef de
// storing exact hetzelfde. Dat sluit een client-side oorzaak vrijwel volledig
// uit — twee onafhankelijke "gratis" commerciële tegel-CDN's die allebei
// dezelfde soort blokkade tonen voor Europa/bepaalde zoomniveaus wijst eerder
// op ingeperkte gratis-tiers dan op toeval. Overgestapt op OpenStreetMap's
// eigen standaardtegels (tile.openstreetmap.org) — het meest gangbare
// universeel-gratis alternatief, met van oudsher sterke Europese dekking op
// alle zoomniveaus. Blijft via de backend lopen (i.p.v. rechtstreeks vanuit de
// browser) omdat OSM's gebruiksbeleid een herkenbare User-Agent verwacht i.p.v.
// een generieke browser-UA — die zetten we hier zelf.
const TEGEL_BASIS_URL = 'https://tile.openstreetmap.org';
const TEGEL_MAX_Z = 19; // OSM's eigen standaardgrens
const TEGEL_USER_AGENT = 'WeerApp/1.0 (persoonlijk zelfgehost hobbyproject, geen commercieel gebruik)';

async function serveTegel(req, res, z, x, y) {
  const zNum = Number(z);
  const xNum = Number(x);
  const yNum = Number(y);
  if (!Number.isInteger(zNum) || !Number.isInteger(xNum) || !Number.isInteger(yNum) || zNum < 0 || zNum > TEGEL_MAX_Z) {
    res.writeHead(400).end('Ongeldige tegel-coördinaten');
    return;
  }
  try {
    // OSM gebruikt de gebruikelijke XYZ-volgorde (z/x/y), geen herordening nodig.
    const upstream = await fetch(`${TEGEL_BASIS_URL}/${zNum}/${xNum}/${yNum}.png`, {
      headers: { 'User-Agent': TEGEL_USER_AGENT },
    });
    if (!upstream.ok) {
      res.writeHead(upstream.status).end();
      return;
    }
    const buffer = Buffer.from(await upstream.arrayBuffer());
    res.writeHead(200, {
      'Content-Type': upstream.headers.get('content-type') ?? 'image/png',
      'Content-Length': buffer.length,
      // 2026-08-19: was 'immutable, max-age=604800' (een week) — bleek een
      // valkuil tijdens het zoeken naar de juiste tegelbron: toen de upstream
      // hier wisselde van Esri naar OSM (zelfde /api/tegel/{z}/{x}/{y}.png-pad)
      // bleef Lex' browser de oude, kapotte respons uit de eigen schijfcache
      // hergebruiken zonder de server ooit opnieuw te vragen. Nu een dag i.p.v.
      // een week, en zonder 'immutable' — nog steeds ruim genoeg om herhaalde
      // round-trips te schelen, maar een volgende wijziging hangt niet meer
      // een week lang vast in Lex' eigen browsercache.
      'Cache-Control': 'public, max-age=86400',
    });
    res.end(buffer);
  } catch (err) {
    console.error('[weer] kaarttegel-proxy mislukt:', err.message ?? err);
    res.writeHead(502).end();
  }
}

// ---- Regenradar-tegel-proxy (RainViewer), 2026-08-19 -----------------------
// Waarom: Lex zag de neerslagradar flink flikkeren — tussen goede tegels en
// een "niet beschikbaar"-plaatje. RainViewer's eigen respons-headers lieten
// X-Ratelimit-Limit/-Used/-Window zien: die bestaan écht bij RainViewer, dus
// vermoedelijk liep dit tijdens dit hele debug-sessie (veel herladen, elke
// framewissel vraagt opnieuw alle zichtbare tegels op) tegen een zacht
// snelheidslimiet aan. Twee maatregelen: (1) de afspeelsnelheid in app.js
// omlaag, en (2) hier een kleine servergeheugen-cache zodat dezelfde tegel
// (zelfde frame + z/x/y) binnen een uur niet nogmaals bij RainViewer wordt
// opgehaald, ook niet als meerdere lagen ('a'/'b') 'm bijna gelijktijdig
// aanvragen. Radartegels voor een reeds gepubliceerd frame veranderen nooit
// meer, dus stevig cachen kan geen kwaad.
const REGENRADAR_HOST = 'https://tilecache.rainviewer.com';
const REGENRADAR_CACHE_MS = 60 * 60 * 1000;
const REGENRADAR_CACHE_MAX = 500; // ruim genoeg voor een paar frames × zichtbare tegels, voorkomt ongelimiteerde groei
const regenradarCache = new Map(); // pad -> { buffer, contentType, tijdMs }

// 2026-08-19, vervolg: los van de rate-limit-flikkering bleek er ook een
// structureel geval — boven de Andes (Peru) liet Lex nog steeds hetzelfde
// "Zoom Level Not Supported"-plaatje zien, óók na de cache-fix. RainViewer is
// een mozaïek van GROND-radars (zie de uitleg bij frameUrl in app.js) — daar
// staat simpelweg geen radarstation, dus dit is vermoedelijk geen storing
// maar RainViewer's (ongelukkig geformuleerde) eigen "geen dekking hier"-
// plaatje. Niet op te lossen (er ís geen data), wel op te lossen hoe lelijk
// het oogt: zo'n plaatje is klein (Lex' voorbeeld was 1370 bytes — een echte
// radartegel, zelfs een lege/regenvrije, is doorgaans groter). Onder een
// ruime drempel vervangen we 'm door een volledig transparant tegeltje, zodat
// je gewoon niets ziet i.p.v. een alarmerende tekstbox. Kleine kans op een
// fout-positief bij een oprecht piepklein (bijna leeg) radartegeltje — die
// wordt dan ook onzichtbaar, wat voor regenradar geen merkbaar verschil is.
const REGENRADAR_PLACEHOLDER_MAX_BYTES = 3000;
const TRANSPARANTE_TEGEL = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=',
  'base64',
);

async function serveRegenradar(req, res, pad) {
  const nu = Date.now();
  const bestaand = regenradarCache.get(pad);
  if (bestaand && nu - bestaand.tijdMs < REGENRADAR_CACHE_MS) {
    res.writeHead(200, {
      'Content-Type': bestaand.contentType,
      'Content-Length': bestaand.buffer.length,
      'Cache-Control': 'public, max-age=3600',
    });
    res.end(bestaand.buffer);
    return;
  }
  try {
    const upstream = await fetch(`${REGENRADAR_HOST}/${pad}`, { headers: { 'User-Agent': TEGEL_USER_AGENT } });
    if (!upstream.ok) {
      res.writeHead(upstream.status).end();
      return;
    }
    let buffer = Buffer.from(await upstream.arrayBuffer());
    if (buffer.length < REGENRADAR_PLACEHOLDER_MAX_BYTES) buffer = TRANSPARANTE_TEGEL;
    const contentType = upstream.headers.get('content-type') ?? 'image/png';

    if (regenradarCache.size >= REGENRADAR_CACHE_MAX) {
      const oudsteSleutel = regenradarCache.keys().next().value; // Map bewaart invoegvolgorde — oudste eerst
      regenradarCache.delete(oudsteSleutel);
    }
    regenradarCache.set(pad, { buffer, contentType, tijdMs: nu });

    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': buffer.length,
      'Cache-Control': 'public, max-age=3600',
    });
    res.end(buffer);
  } catch (err) {
    console.error('[weer] regenradar-tegel-proxy mislukt:', err.message ?? err);
    res.writeHead(502).end();
  }
}

// ---- Idle-detectie voor credit-gelimiteerde bronnen, 2026-08-19 ------------
// Aanleiding: Lex' terechte vraag "of staat de server dat straks op default
// te doen?" — ja, elke bron met een pollIntervalMs draait via setInterval
// altijd door zolang het proces leeft, los van of iemand de app open heeft.
// Voor de meeste bronnen (officiële overheids-API's) maakt dat weinig uit,
// maar Lifeliner (OpenSky, anoniem) heeft een harde 400-credits/dag-limiet —
// 24/7 doorpollen op een snel tempo zou dat budget alsnog opsouperen, ook al
// wil Lex juist een kort interval (1 min of sneller) voor minder lag. Lex'
// eigen gebruikspatroon lost dat op: 1 gebruiker, een paar keer per dag een
// kwartier — dus alleen ECHT pollen zolang er ook een client kijkt, i.p.v. op
// tijd-budget te bezuinigen. Bronnen met `overslaanAlsIdle: true` in
// config.js (nu alleen lifeliner) worden overgeslagen zodra er langer dan
// IDLE_DREMPEL_MS geen /api/signals-verzoek is binnengekomen; zodra er weer
// een client verschijnt, wordt zo'n bron met voorrang meteen ververst i.p.v.
// te wachten tot het eerstvolgende interval-tikje.
const IDLE_DREMPEL_MS = 90 * 1000; // iets ruimer dan de frontend-ververscyclus (20s), tegen valse idle-flapping

// Extra laag boven de idle-gate, specifiek voor lifeliner (2026-08-19, op
// verzoek van Lex): ook tíjdens een sessie heeft OpenSky-pollen weinig zin
// als er simpelweg niks vliegt. p2000.js signaleert een mogelijke MMT-
// ("Mobiel Medisch Team", de meldkamer-oproep bij een traumaheli-inzet)
// dispatch — zolang die minder dan dit venster geleden is, polt lifeliner
// door, ook zonder actieve client (zodat de data al warm staat tegen de tijd
// dat iemand de app opent). 45 minuten is een ruime inschatting van een
// typische MMT-missieduur (uitvliegen + ter plaatse + terugvliegen).
const LIFELINER_TRIGGER_VENSTER_MS = 45 * 60 * 1000;

export function createApp(env) {
  const states = new Map(SOURCES.map((s) => [s.id, new SourceState(s)]));
  const timers = [];
  let stopBlitzortung = null;
  // Startwaarde = nu, niet 0 — anders zou "nog nooit een client gezien"
  // (bijv. vlak na een herstart 's nachts) meteen als "actief" tellen i.p.v.
  // als idle, en zou deze hele bezuiniging pas ingaan ná de eerste bezoeker.
  let laatsteClientMs = Date.now();

  function isIdle() {
    return Date.now() - laatsteClientMs > IDLE_DREMPEL_MS;
  }

  // Aanroepen vanuit elk /api/signals*-verzoek: onthoudt "er is net iemand",
  // en als de app ná een idle-periode weer wordt geopend, meteen (niet pas na
  // het volgende interval-tikje) de idle-gepauzeerde bronnen verversen — dus
  // geen extra wachttijd bovenop de tijd dat de app al dicht was.
  function signaalVerzoekOntvangen() {
    const kwamUitIdle = isIdle();
    laatsteClientMs = Date.now();
    if (kwamUitIdle) {
      for (const source of SOURCES) {
        if (source.overslaanAlsIdle && source.implemented) pollOnce(source.id);
      }
    }
  }
  // Los van de SOURCES/signalen-machinerie hierboven: dit is geen hazard-
  // signaal maar statische referentiegeodata (NEXRAD-stationslocaties) voor
  // de Doppler-"Rotatie"-lookup in de frontend. Vandaar een eigen kleine
  // cache i.p.v. SourceState — die verwacht makeSignal()-achtige objecten
  // met categorie/ernst, wat hier niet van toepassing is.
  let nexradStations = [];
  let nexradStationsBijgewerkt = null;

  async function ververNexradStations() {
    try {
      nexradStations = await fetchNexradStations();
      nexradStationsBijgewerkt = new Date().toISOString();
    } catch (err) {
      // Vorige lijst (indien aanwezig) blijft gewoon staan — beter een iets
      // oudere lijst (radarlocaties veranderen sowieso vrijwel nooit) dan
      // een lege lijst voor de rotatie-lookup.
      console.error('[weer] nexradStations poll mislukt:', err.message ?? err);
    }
  }

  async function pollOnce(sourceId) {
    const state = states.get(sourceId);
    const fetcher = FETCHERS[sourceId];
    if (!state || !fetcher) return;
    if (state.config.overslaanAlsIdle && isIdle()) {
      // Uitzondering voor lifeliner: een recente MMT-dispatch (zie p2000.js)
      // rechtvaardigt doorpollen, ook zonder kijkende client.
      const recenteMMTTrigger = sourceId === 'lifeliner' && msSindsLaatsteMMTMelding() < LIFELINER_TRIGGER_VENSTER_MS;
      if (!recenteMMTTrigger) return; // credit-budget sparen zolang niemand kijkt én er niets vliegt
    }
    try {
      const signals = await fetcher(env);
      state.markSuccess(signals);
    } catch (err) {
      state.markError(err);
      console.error(`[weer] ${sourceId} poll mislukt:`, err.message ?? err);
    }
  }

  function startPolling() {
    for (const source of SOURCES) {
      if (source.id === 'blitzortung') continue; // streaming, geen timer-polling — zie hieronder
      if (!source.implemented || source.pollIntervalMs == null) continue;
      pollOnce(source.id); // meteen bij opstarten, niet pas na het eerste interval
      const timer = setInterval(() => pollOnce(source.id), source.pollIntervalMs);
      timers.push(timer);
    }

    // Radarlocaties zijn vrijwel statisch — eenmaal bij opstarten ophalen is
    // genoeg, maar 1x/dag verversen kan geen kwaad (en vangt op als NOAA ooit
    // een station toevoegt/verwijdert) zonder dat het als een "bron" met
    // stale/haperend-status in Instellingen hoeft te verschijnen.
    ververNexradStations();
    timers.push(setInterval(ververNexradStations, 24 * 60 * 60 * 1000));

    const blitzortungBron = SOURCES.find((s) => s.id === 'blitzortung');
    if (blitzortungBron?.implemented) {
      const state = states.get('blitzortung');
      stopBlitzortung = startBlitzortungStream({
        homeLat: env.homeLat,
        homeLon: env.homeLon,
        onUpdate: (signalen) => state.markSuccess(signalen),
        onError: (err) => {
          state.markError(err);
          console.error('[weer] blitzortung:', err.message ?? err);
        },
      });
    }
  }

  function stopPolling() {
    timers.forEach(clearInterval);
    if (stopBlitzortung) stopBlitzortung();
  }

  function signalenMet(filterCategorie) {
    return [...states.values()].flatMap((state) =>
      state.signals
        .filter((s) => !filterCategorie || s.categorie === filterCategorie)
        .map((signal) => ({
          ...signal,
          bron: {
            id: state.config.id,
            naam: state.config.naam,
            tier: state.config.tier,
            bijgewerkt: state.lastSuccessAt,
            haperend: state.isStale(),
          },
        })),
    );
  }

  async function serveStatic(req, res) {
    const urlPath = decodeURIComponent(req.url.split('?')[0]);
    const relPath = urlPath === '/' ? '/index.html' : urlPath;
    const filePath = join(env.frontendDir ?? 'frontend', relPath);
    // simpele traversal-check
    if (!filePath.startsWith(env.frontendDir ?? 'frontend')) {
      res.writeHead(403).end('Verboden');
      return;
    }
    try {
      const s = await stat(filePath);
      if (!s.isFile()) throw new Error('geen bestand');
      const data = await readFile(filePath);
      res.writeHead(200, { 'Content-Type': MIME[extname(filePath)] ?? 'application/octet-stream' });
      res.end(data);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Niet gevonden');
    }
  }

  const server = createServer(async (req, res) => {
    const url = req.url.split('?')[0];

    if (url === '/api/config') {
      return sendJson(res, 200, {
        homeLat: env.homeLat,
        homeLon: env.homeLon,
        homeLabel: env.homeLabel ?? 'Thuis',
      });
    }
    if (url === '/api/radarstations') {
      return sendJson(res, 200, { stations: nexradStations, bijgewerkt: nexradStationsBijgewerkt });
    }
    if (url === '/api/status') {
      return sendJson(res, 200, { bronnen: SOURCES.map((s) => states.get(s.id).toStatus()) });
    }
    if (url === '/api/signals') {
      signaalVerzoekOntvangen();
      const signalen = signalenMet(null);
      return sendJson(res, 200, { signalen, aantal: signalen.length });
    }
    const catMatch = url.match(/^\/api\/signals\/([a-z-]+)$/);
    if (catMatch) {
      signaalVerzoekOntvangen();
      const signalen = signalenMet(catMatch[1]);
      return sendJson(res, 200, { signalen, aantal: signalen.length });
    }
    const tegelMatch = url.match(/^\/api\/tegel\/(\d+)\/(\d+)\/(\d+)\.png$/);
    if (tegelMatch) {
      return serveTegel(req, res, tegelMatch[1], tegelMatch[2], tegelMatch[3]);
    }
    const regenradarMatch = url.match(/^\/api\/regenradar\/(.+)$/);
    if (regenradarMatch) {
      return serveRegenradar(req, res, regenradarMatch[1]);
    }

    return serveStatic(req, res);
  });

  return { server, startPolling, stopPolling, states };
}
