// Minimale service worker — vooral om de PWA installeerbaar te maken
// (icoon op het homescreen zetten op iPhone/iPad). Geen agressieve caching
// van /api/* data, want die moet altijd vers zijn.
//
// Strategie voor de schil (html/css/js): network-first met cache als fallback.
// Tijdens actieve ontwikkeling wil je namelijk altijd de nieuwste versie zien
// zodra je online bent — de cache is puur een vangnet voor als de
// aggregator-service even niet bereikbaar is. Verhoog CACHE_NAAM telkens als
// je wilt garanderen dat oude installaties de nieuwe versie ophalen.

const CACHE_NAAM = 'weer-shell-v12';
const SHELL_BESTANDEN = ['/', '/index.html', '/styles.css', '/app.js', '/manifest.webmanifest'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAAM).then((cache) => cache.addAll(SHELL_BESTANDEN)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((namen) => Promise.all(namen.filter((n) => n !== CACHE_NAAM).map((n) => caches.delete(n)))),
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (url.pathname.startsWith('/api/')) return; // nooit cachen, altijd live data

  event.respondWith(
    fetch(event.request)
      .then((netwerkResponse) => {
        const kopie = netwerkResponse.clone();
        caches.open(CACHE_NAAM).then((cache) => cache.put(event.request, kopie));
        return netwerkResponse;
      })
      .catch(() => caches.match(event.request)), // alleen terugvallen op cache als het netwerk faalt
  );
});
