// Simpele, dependency-loze frontend: haalt /api/signals en /api/status op
// en rendert de Storm Noir-schil ermee. Geen framework — makkelijk uit te
// breiden zodra er meer bronnen echt geïmplementeerd zijn.
//
// UI-structuur: vaste bottom-nav met 4 tabbladen (Kaart / Meldingen / Hemel /
// Instellingen) i.p.v. een scrollende ticker + horizontale sleepbalk. Een
// melding aantikken in de Meldingen-lijst centreert de kaart erop en opent
// de popup van dat signaal.

const LOC_NAAM_EL = document.getElementById('locNaam');
const KLOK_EL = document.getElementById('klok');
const VERBINDING_EL = document.getElementById('verbinding');
const BIJGEWERKT_EL = document.getElementById('bijgewerkt');
const SKY_LIJST_EL = document.getElementById('skyLijst');
const HEMEL_LEEG_EL = document.getElementById('hemelLeeg');
const ERROR_EL = document.getElementById('errorBanner');
const HEADER_TEMP_EL = document.getElementById('headerTemp');
const WEATHER_CARD_EL = document.getElementById('weatherCard');
const WEER_CONDITIE_EL = document.getElementById('weerConditie');
const WEER_TEMP_EL = document.getElementById('weerTemp');
const WEER_GEVOEL_EL = document.getElementById('weerGevoel');
const WEER_WIND_EL = document.getElementById('weerWind');
const WEER_STOTEN_EL = document.getElementById('weerStoten');
const WEER_VOCHT_EL = document.getElementById('weerVocht');
const WEER_DRUK_EL = document.getElementById('weerDruk');
const WEER_BEWOLKING_EL = document.getElementById('weerBewolking');
const TOGGLE_DOPPLER_EL = document.getElementById('toggleDoppler');
const DOPPLER_PRODUCTEN_EL = document.getElementById('dopplerProducten');
const RADAR_SPEEL_EL = document.getElementById('radarSpeel');
const RADAR_TIJD_EL = document.getElementById('radarTijd');
const TOGGLE_SATELLIET_EL = document.getElementById('toggleSatelliet');
const TOGGLE_REGENRADAR_EL = document.getElementById('toggleRegenradar');
const MELDINGEN_LIJST_EL = document.getElementById('meldingenLijst');
const MELDINGEN_BADGE_EL = document.getElementById('meldingenBadge');
const INST_LOCATIE_EL = document.getElementById('instLocatie');
const BOTTOM_NAV_EL = document.getElementById('bottomNav');
const ALARM_GLOED_EL = document.getElementById('alarmGloed');
const ALARM_POPUP_EL = document.getElementById('alarmPopup');
const ALARM_POPUP_ICOON_EL = document.getElementById('alarmPopupIcoon');
const ALARM_POPUP_TITEL_EL = document.getElementById('alarmPopupTitel');
const ALARM_POPUP_SUB_EL = document.getElementById('alarmPopupSub');
const ALARM_POPUP_BEKIJK_EL = document.getElementById('alarmPopupBekijk');
const ALARM_POPUP_SLUIT_EL = document.getElementById('alarmPopupSluit');

function updateKlok() {
  KLOK_EL.textContent = new Date().toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
}

function geledenTekst(ts) {
  if (!ts) return 'nog niet';
  const sec = Math.round((Date.now() - ts) / 1000);
  if (sec < 60) return `${sec}s geleden`;
  if (sec < 3600) return `${Math.round(sec / 60)} min geleden`;
  return `${Math.round(sec / 3600)} uur geleden`;
}

// ---- Tabbladen (bottom-nav) -------------------------------------------
const VIEWS = ['kaart', 'meldingen', 'hemel', 'instellingen'];
let huidigeView = 'kaart';

function wisselView(naam) {
  huidigeView = naam;
  VIEWS.forEach((v) => {
    document.getElementById(`view${v[0].toUpperCase()}${v.slice(1)}`).classList.toggle('verborgen', v !== naam);
  });
  BOTTOM_NAV_EL.querySelectorAll('.nav-btn').forEach((btn) => {
    btn.classList.toggle('actief', btn.dataset.view === naam);
  });
  // Leaflet tekent tegels verkeerd als de container display:none heeft gehad —
  // na terugschakelen naar de kaarttab de afmeting laten herberekenen.
  if (naam === 'kaart' && kaart) {
    setTimeout(() => kaart.invalidateSize(), 0);
  }
}

BOTTOM_NAV_EL.querySelectorAll('.nav-btn').forEach((btn) => {
  btn.addEventListener('click', () => wisselView(btn.dataset.view));
});

// Wordt bij het opstarten één keer gevuld vanuit /api/config.
let THUIS = { homeLat: 52.0907, homeLon: 5.1214, homeLabel: '—' };

// Echte Leaflet-kaart met donkere CARTO-tegels (gratis, geen sleutel nodig) —
// vervangt de eerdere schematische plek-simulatie door een echte projectie.
let kaart = null;
let signaalLaag = null;
let flitsenLaag = null; // losse laag voor individuele bliksemflitsen van een aangetikt onweercomplex
let geselecteerdComplexId = null; // welk onweercomplex de flitsenlaag nu volgt, voor live meeverversen
let gebiedLaag = null; // losse laag voor de polygon-omtrek van een aangetikt gebied-signaal (tornado-watch, severe-outlook) én, sinds 2026-08-17, de NHC-voorspelde-koers (cone + lijn) van een orkaan
let geselecteerdGebiedId = null; // welk gebied-signaal de gebiedLaag nu volgt, voor live meeverversen
let dopplerLaag = null; // optionele NEXRAD-Doppler-radarlaag (VS), alleen relevant bij tornado-gerelateerde meldingen
let dopplerActief = false;
let dopplerProduct = 'reflectiviteit'; // 'reflectiviteit' (landelijke mozaïek) | 'rotatie' (per-station Storm-Relative Velocity)
let dopplerSignaal = null; // huidig aangetikte signaal, nodig om het dichtstbijzijnde radarstation te bepalen bij 'rotatie'
let markersPerId = new Map(); // signal-id -> Leaflet marker, voor "centreer op melding"

const EMOJI_PER_CATEGORIE = {
  aardbeving: '🌋',
  orkaan: '🌀',
  // Vormingsgebied (nog geen naam/storm) — bewust een ander icoon dan 🌀,
  // zodat je op de kaart meteen ziet dat dit nog géén actieve orkaan is.
  cycloonvorming: '➰',
  onweer: '⚡',
  onweercomplex: '🌩️',
  tornado: '🌪',
  'tornado-watch': '🌪️',
  'tornado-bevestigd': '🌪',
  'severe-outlook': '⛈️',
  overstroming: '🌊',
  natuurbrand: '🔥',
  vulkaan: '🗻',
  droogte: '🏜️',
  weerwaarschuwing: '⚠️',
  // Brandweer/politie/ambulance (P2000) + Lifeliner-traumahelikopters, 2026-08-19
  // — zie backend/src/sources/p2000.js en lifeliner.js.
  hulpdiensten: '🚨',
};
// Categorieën met rijkere popup-inhoud (plaatjes/tekstblokken, zie
// popupExtraHtml) krijgen een bredere Leaflet-popup dan de standaard 240px.
const POPUP_BREED_CATEGORIEEN = new Set(['orkaan', 'aardbeving', 'cycloonvorming']);
// Categorieën waarbij de Doppler-radarknop (VS-specifiek, zie toggleDoppler)
// zinvolle context geeft — puur VS-tornado-gerelateerde signalen.
const DOPPLER_CATEGORIEEN = new Set(['tornado', 'tornado-watch', 'tornado-bevestigd', 'severe-outlook']);
const ERNST_PRIORITEIT = { kritiek: 0, waarschuwing: 1, 'let-op': 2, info: 3 };

// Categorieën die al een eigen tab/kaart hebben (Hemel, het weerkaartje) en
// geen kaartlocatie hebben — die horen niet nogmaals in de Meldingen-lijst.
const MELDINGEN_CATEGORIEEN_UITGESLOTEN = new Set(['hemel', 'algemeen-weer']);

function initMap() {
  kaart = L.map('map', { attributionControl: true, zoomControl: true, maxZoom: 18 }).setView([THUIS.homeLat, THUIS.homeLon], 6);

  // Losse pane voor de wolkenfilm, boven de basiskaart-tiles maar onder de
  // markers — houdt de radarlaag ook onafhankelijk instelbaar (bijv. een
  // eigen CSS-filter) zonder de basiskaart te raken, mocht dat later nodig zijn.
  kaart.createPane('radarPane');
  kaart.getPane('radarPane').style.zIndex = 450;
  // Onder de neerslagradar (die moet er overheen blijven zichtbaar), maar
  // boven de kaarttegels zelf — zie satellietLaag hieronder.
  kaart.createPane('satellietPane');
  kaart.getPane('satellietPane').style.zIndex = 350;

  // 2026-08-19: basiskaart-geschiedenis (kort) — CARTO's gratis dark_all gaf
  // in Europa een ingebakken "Zoom Level Not Supported"-plaatje (HTTP 200,
  // dus geen netwerkfout). Overgestapt op Esri's Dark Gray Canvas: zelfde
  // probleem, eerst op de Reference-laag (labels), daarna zelfs op de
  // Base-laag. Ook toen de backend zélf (server-side, dus los van Lex'
  // browser/netwerk/service-worker) de tegel ophaalde bleef het identiek —
  // dat sluit een client-side oorzaak zo goed als uit. Definitieve keuze:
  // OpenStreetMap's eigen standaardtegels, met van oudsher sterke Europese
  // dekking, opgehaald via de eigen backend-proxy (/api/tegel/{z}/{x}/{y}.png,
  // zie server.js — OSM's gebruiksbeleid wil een herkenbare User-Agent, die
  // zet de backend zelf). OSM-tegels zijn licht/kleurrijk i.p.v. donker, dus
  // de CSS-filter in styles.css (#map .leaflet-tile-pane) is meegewijzigd
  // naar een invert-gebaseerde donkere-modus-look.
  //
  // 2026-08-19, vervolg: `?v=osm1` is geen willekeurige toevoeging — zonder
  // cache-buster bleven tegels die Lex tijdens de CARTO/Esri-fases al had
  // bekeken (vooral Nederland, tientallen keren herladen tijdens het
  // debuggen) uit zijn browser-schijfcache komen i.p.v. vers bij de nieuwe
  // OSM-proxy opgehaald — zichtbaar als een harde naad op de kaart: één kant
  // vlak/grijzig (oude Esri Dark-Gray-Canvas-tegels, nog binnen de 1-dag
  // cache-tijd), de andere kant fris en kleurrijk (nooit eerder bekeken
  // gebied, dus een echte nieuwe OSM-fetch). De querystring maakt elke oude
  // gecachete tegel-URL ongeldig voor de browser, zodat alles nu gegarandeerd
  // vers wordt opgehaald — de backend zelf negeert querystrings toch al bij
  // het matchen van de route.
  L.tileLayer('/api/tegel/{z}/{x}/{y}.png?v=osm1', {
    attribution: '© OpenStreetMap-auteurs',
    maxZoom: 19,
  }).addTo(kaart);

  L.marker([THUIS.homeLat, THUIS.homeLon], {
    icon: L.divIcon({ className: '', html: '<div class="home-pin"></div>', iconSize: [14, 14], iconAnchor: [7, 7] }),
    interactive: false,
  }).addTo(kaart);

  signaalLaag = L.layerGroup().addTo(kaart);
  flitsenLaag = L.layerGroup().addTo(kaart);
  // featureGroup i.p.v. layerGroup: die heeft getBounds(), nodig om de kaart
  // op de hele omtrek te laten inzoomen i.p.v. op het (mogelijk misleidende)
  // zwaartepunt bij een groot gebied als een tornado-watch.
  gebiedLaag = L.featureGroup().addTo(kaart);

  TOGGLE_DOPPLER_EL.addEventListener('click', toggleDoppler);
  DOPPLER_PRODUCTEN_EL.querySelectorAll('.doppler-product-btn').forEach((btn) => {
    btn.addEventListener('click', () => kiesDopplerProduct(btn.dataset.product));
  });
  RADAR_SPEEL_EL.addEventListener('click', () => (radarSpelend ? radarAfspelenStop() : radarAfspelenStart()));
  TOGGLE_SATELLIET_EL.addEventListener('click', toggleSatelliet);
  TOGGLE_REGENRADAR_EL.addEventListener('click', toggleRegenradar);

  // regenradarAan staat standaard op true (zie sectie verderop) — dus meteen
  // bij het opstarten de knop als "actief" tonen en de radar laden, i.p.v. te
  // wachten tot iemand er zelf op klikt.
  if (regenradarAan) {
    TOGGLE_REGENRADAR_EL.classList.add('actief');
    initRadar();
  }
}

// ---- NEXRAD-Doppler-radar (VS) — losse, optionele laag bovenop een
// tornado-gerelateerde melding. Bron: Iowa Environmental Mesonet, gratis,
// geen sleutel. https://mesonet.agron.iastate.edu/
// Los van RainViewer (die is wereldwijd maar lagere resolutie) — dit is
// specifiek de "echte" Amerikaanse Doppler-radar, alleen zinvol/zichtbaar
// gemaakt bij VS-tornado-signalen (zie DOPPLER_CATEGORIEEN), niet als
// permanente derde kaartstand naast Gevaren/Weer.
//
// Twee kiesbare producten (knopjes onder de Doppler-toggle):
//  - reflectiviteit: landelijke IEM-mozaïek (N0Q), overal in de VS zichtbaar.
//  - rotatie: Storm-Relative Velocity (N0S) van één specifiek radarstation —
//    dit is het product dat spotters/professionals gebruiken om rotatie/
//    tornado-signatuur te zien (ruwe velocity zonder storm-motion-correctie
//    is veel lastiger af te lezen). IEM biedt geen landelijke velocity-
//    mozaïek (velocity is inherent radar-relatief), dus dit MOET per station.
//
// Stationslijst hieronder is een handmatig samengestelde subset (~Tornado
// Alley, Dixie Alley en het zuidoosten van de VS — de gebieden met verreweg
// de meeste tornado's) i.p.v. het volledige landelijke NEXRAD-netwerk van
// ~160 stations. Reden: een betrouwbare, actuele volledige lijst kon niet
// worden opgehaald (herhaalde ROBOTS_DISALLOWED-fouten bij twee externe
// bronnen tijdens het bouwen hiervan) en deze coördinaten komen uit
// algemene kennis over deze (al decennia vaste, publieke) radarlocaties,
// niet uit een live-geverifieerde bron. Ruim voldoende nauwkeurig voor
// "dichtstbijzijnde station kiezen" (stations liggen doorgaans >150km uit
// elkaar), maar dus bewust geen landelijke dekking — bij een melding ver
// buiten deze regio's toont de rotatie-knop dan niets (zie
// dopplerTileUrlVoor hieronder), i.p.v. een station te ver weg te tonen.
// Fallback voor als /api/radarstations (nieuw, zie laadRadarstations hieronder)
// niet lukt — dan valt dichtstbijzijndeRadarstation() terug op deze
// handmatig samengestelde ~40-stations-lijst rond Tornado Alley/Dixie
// Alley/zuidoost-VS, i.p.v. de rotatie-optie helemaal te laten uitvallen.
const NEXRAD_STATIONS_FALLBACK = [
  { id: 'KTLX', naam: 'Twin Lakes, OK', lat: 35.333, lon: -97.278 },
  { id: 'KFDR', naam: 'Frederick, OK', lat: 34.362, lon: -98.976 },
  { id: 'KVNX', naam: 'Vance AFB, OK', lat: 36.741, lon: -98.128 },
  { id: 'KINX', naam: 'Tulsa, OK', lat: 36.175, lon: -95.564 },
  { id: 'KICT', naam: 'Wichita, KS', lat: 37.654, lon: -97.443 },
  { id: 'KDDC', naam: 'Dodge City, KS', lat: 37.761, lon: -99.969 },
  { id: 'KGLD', naam: 'Goodland, KS', lat: 39.367, lon: -101.700 },
  { id: 'KTWX', naam: 'Topeka, KS', lat: 38.997, lon: -96.232 },
  { id: 'KUEX', naam: 'Hastings, NE', lat: 40.321, lon: -98.442 },
  { id: 'KOAX', naam: 'Omaha, NE', lat: 41.320, lon: -96.367 },
  { id: 'KLNX', naam: 'North Platte, NE', lat: 41.958, lon: -100.576 },
  { id: 'KABR', naam: 'Aberdeen, SD', lat: 45.456, lon: -98.413 },
  { id: 'KFSD', naam: 'Sioux Falls, SD', lat: 43.588, lon: -96.729 },
  { id: 'KAMA', naam: 'Amarillo, TX', lat: 35.233, lon: -101.709 },
  { id: 'KLBB', naam: 'Lubbock, TX', lat: 33.654, lon: -101.814 },
  { id: 'KFWS', naam: 'Dallas/Fort Worth, TX', lat: 32.573, lon: -97.303 },
  { id: 'KEWX', naam: 'Austin/San Antonio, TX', lat: 29.704, lon: -98.028 },
  { id: 'KHGX', naam: 'Houston, TX', lat: 29.472, lon: -95.079 },
  { id: 'KGRK', naam: 'Fort Hood/Waco, TX', lat: 30.722, lon: -97.383 },
  { id: 'KDYX', naam: 'Abilene, TX', lat: 32.538, lon: -99.254 },
  { id: 'KSJT', naam: 'San Angelo, TX', lat: 31.371, lon: -100.492 },
  { id: 'KDFX', naam: 'Del Rio, TX', lat: 29.273, lon: -100.280 },
  { id: 'KSHV', naam: 'Shreveport, LA', lat: 32.451, lon: -93.841 },
  { id: 'KLCH', naam: 'Lake Charles, LA', lat: 30.125, lon: -93.216 },
  { id: 'KPOE', naam: 'Fort Polk, LA', lat: 31.155, lon: -92.976 },
  { id: 'KLIX', naam: 'New Orleans, LA', lat: 30.337, lon: -89.825 },
  { id: 'KLZK', naam: 'Little Rock, AR', lat: 34.836, lon: -92.262 },
  { id: 'KSRX', naam: 'Fort Smith, AR', lat: 35.290, lon: -94.362 },
  { id: 'KMEG', naam: 'Memphis, TN', lat: 35.345, lon: -90.081 },
  { id: 'KHTX', naam: 'Huntsville, AL', lat: 34.931, lon: -86.084 },
  { id: 'KBMX', naam: 'Birmingham, AL', lat: 33.172, lon: -86.770 },
  { id: 'KMXX', naam: 'Montgomery, AL', lat: 32.537, lon: -85.790 },
  { id: 'KMOB', naam: 'Mobile, AL', lat: 30.679, lon: -88.240 },
  { id: 'KDGX', naam: 'Jackson, MS', lat: 32.280, lon: -89.985 },
  { id: 'KGWX', naam: 'Columbus AFB, MS', lat: 33.897, lon: -88.329 },
  { id: 'KFFC', naam: 'Atlanta, GA', lat: 33.364, lon: -84.566 },
  { id: 'KVAX', naam: 'Valdosta/Moody AFB, GA', lat: 30.890, lon: -83.002 },
  { id: 'KJGX', naam: 'Robins AFB/Macon, GA', lat: 32.675, lon: -83.351 },
  { id: 'KCLX', naam: 'Charleston, SC', lat: 32.656, lon: -81.042 },
  { id: 'KGSP', naam: 'Greenville/Spartanburg, SC', lat: 34.883, lon: -82.220 },
  { id: 'KRAX', naam: 'Raleigh/Durham, NC', lat: 35.665, lon: -78.490 },
  { id: 'KMHX', naam: 'Newport/Morehead City, NC', lat: 34.776, lon: -76.876 },
];

// Wordt bij het opstarten gevuld vanuit /api/radarstations (volledige
// landelijke NEXRAD-lijst, ~159 stations, backend: nexradStations.js). Blijft
// `null` (en dus fallback naar de curated lijst hierboven) zolang die fetch
// nog niet is geweest of is mislukt.
let NEXRAD_STATIONS_VOLLEDIG = null;

function afstandKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function dichtstbijzijndeRadarstation(lat, lon) {
  if (lat == null || lon == null) return null;
  const lijst = NEXRAD_STATIONS_VOLLEDIG?.length ? NEXRAD_STATIONS_VOLLEDIG : NEXRAD_STATIONS_FALLBACK;
  let beste = null;
  let besteAfstand = Infinity;
  for (const station of lijst) {
    const d = afstandKm(lat, lon, station.lat, station.lon);
    if (d < besteAfstand) {
      besteAfstand = d;
      beste = station;
    }
  }
  // Bij de volledige landelijke lijst liggen stations doorgaans <230km uit
  // elkaar (dat is precies waarom NEXRAD zo'n dekkingsdichtheid heeft) — een
  // ruimere marge (400km) dan de oude 350km, om ook afgelegen eilanden/
  // Alaska (grotere onderlinge afstanden) nog een station te geven i.p.v.
  // een lege rotatie-knop. Bij de curated fallback-lijst (smaller gebied)
  // blijft dit verder hetzelfde principe: liever niets tonen dan een
  // misleidend ver-weg station.
  return beste && besteAfstand <= 400 ? beste : null;
}

async function laadRadarstations() {
  try {
    const body = await fetch('/api/radarstations').then((r) => r.json());
    if (Array.isArray(body?.stations) && body.stations.length) {
      NEXRAD_STATIONS_VOLLEDIG = body.stations;
    }
  } catch {
    // Stil falen — dichtstbijzijndeRadarstation() valt vanzelf terug op
    // NEXRAD_STATIONS_FALLBACK zolang NEXRAD_STATIONS_VOLLEDIG leeg blijft.
  }
}

function dopplerTileInfo(product, signal) {
  if (product === 'reflectiviteit') {
    return {
      url: 'https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/nexrad-n0q-900913/{z}/{x}/{y}.png',
      attributie: 'Radar: Iowa Environmental Mesonet (NEXRAD-mozaïek, reflectiviteit)',
    };
  }
  // rotatie (Storm-Relative Velocity) — vereist een dichtstbijzijnd station
  const station = dichtstbijzijndeRadarstation(signal?.lat, signal?.lon);
  if (!station) return null;
  return {
    url: `https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/ridge::${station.id}-N0S-0/{z}/{x}/{y}.png`,
    attributie: `Radar: IEM — ${station.naam} (${station.id}), Storm-Relative Velocity`,
  };
}

// Laag opnieuw opbouwen i.p.v. hergebruiken: het gekozen product of het
// onderliggende station (bij 'rotatie', afhankelijk van het aangetikte
// signaal) kan wijzigen terwijl Doppler al aanstaat.
function herbouwDopplerLaag() {
  if (!kaart) return;
  if (dopplerLaag) {
    kaart.removeLayer(dopplerLaag);
    dopplerLaag = null;
  }
  if (!dopplerActief) return;
  const info = dopplerTileInfo(dopplerProduct, dopplerSignaal);
  if (!info) return; // bv. 'rotatie' gekozen maar geen station binnen bereik — stil niets tonen
  dopplerLaag = L.tileLayer(info.url, {
    attribution: info.attributie,
    opacity: 0.65,
    maxZoom: 12,
    pane: 'radarPane',
  }).addTo(kaart);
}

function toggleDoppler() {
  dopplerActief = !dopplerActief;
  TOGGLE_DOPPLER_EL.classList.toggle('actief', dopplerActief);
  // Productknoppen (Reflectiviteit/Rotatie) pas tonen zodra Doppler zelf
  // aanstaat — op verzoek van Lex, voorkomt twee knoppenrijen die niets doen
  // voordat je Doppler hebt aangezet.
  DOPPLER_PRODUCTEN_EL.style.display = dopplerActief ? '' : 'none';
  herbouwDopplerLaag();
}

function kiesDopplerProduct(product) {
  if (product === dopplerProduct) return;
  dopplerProduct = product;
  DOPPLER_PRODUCTEN_EL.querySelectorAll('.doppler-product-btn').forEach((btn) => {
    btn.classList.toggle('actief', btn.dataset.product === product);
  });
  if (dopplerActief) herbouwDopplerLaag();
}

// Knop(en) alleen tonen bij VS-tornado-gerelateerde meldingen — bij elke
// andere selectie verbergen én uitzetten, anders blijft de radar "aan"
// hangen terwijl de knop niet meer zichtbaar is om 'm uit te zetten.
function toonDopplerKnopVoor(signal) {
  const relevant = DOPPLER_CATEGORIEEN.has(signal.categorie);
  TOGGLE_DOPPLER_EL.style.display = relevant ? '' : 'none';
  // Productknoppen alleen zichtbaar zolang Doppler ook echt aanstaat — niet
  // al zodra de Doppler-toggle zelf maar zichtbaar is (zie toggleDoppler()).
  DOPPLER_PRODUCTEN_EL.style.display = relevant && dopplerActief ? '' : 'none';
  dopplerSignaal = relevant ? signal : null;
  if (!relevant) {
    dopplerActief = false;
    TOGGLE_DOPPLER_EL.classList.remove('actief');
    DOPPLER_PRODUCTEN_EL.style.display = 'none';
  }
  herbouwDopplerLaag(); // ook nodig als nog wél relevant: nieuw signaal kan een ander station betekenen bij 'rotatie'
}

// Tik op een melding: schakel naar de kaarttab, centreer erop en open de popup.
function centreerOpMelding(signal) {
  wisselView('kaart');
  // De wolkenfilm-lagen (RainViewer) ondersteunen maar tot zoom 12 — dat is
  // afgedwongen via de eigen `maxZoom: 12` van radarLagen zelf (zie
  // toonRadarFrame), dus Leaflet laat die lagen al netjes leeg boven dat
  // zoomniveau i.p.v. een "zoom level not supported"-tegel te tonen. Geen
  // aparte Gevaren/Weer-stand meer nodig om dat te voorkomen.
  // Onthouden welk complex nu bekeken wordt, zodat de flitsenlaag meelift met
  // elke volgende 20-seconden-verversing (zie ververGeselecteerdeFlitsen) i.p.v.
  // alleen een momentopname te blijven op het moment van aantikken.
  geselecteerdComplexId = signal.categorie === 'onweercomplex' ? signal.id : null;
  toonFlitsenVoor(signal);
  toonDopplerKnopVoor(signal);
  const gebied = toonGebiedVoor(signal);
  // Zelfde live-meeverversen-principe als bij flitsen (zie
  // ververGeselecteerdGebied): onthouden welk gebied-signaal openstaat, zodat
  // de omtrek meelift op de bestaande 20-seconden-cyclus i.p.v. een
  // momentopname te blijven — belangrijk omdat NWS een watch kan aanpassen of
  // laten verlopen terwijl je 'm openhoudt.
  geselecteerdGebiedId = gebied ? signal.id : null;
  if (!kaart) return;
  if (gebied) {
    // Groot gebied (bv. een tornado-watch over meerdere staten) — inzoomen op
    // de hele omtrek i.p.v. op het zwaartepunt, anders zie je maar een klein
    // stukje van waar de watch daadwerkelijk geldt.
    kaart.fitBounds(gebied.getBounds(), { padding: [24, 24] });
  } else if (signal.lat != null && signal.lon != null) {
    kaart.setView([signal.lat, signal.lon], Math.max(kaart.getZoom(), 8));
  } else {
    return;
  }
  const marker = markersPerId.get(signal.id);
  if (marker) setTimeout(() => marker.openPopup(), 250); // wacht tot de pan/zoom-animatie klaar is
}

// Bij een aangetikt gebied-signaal (nu: tornado-watch, severe-outlook) de
// polygon-omtrek van het gebied tekenen i.p.v. alleen het zwaartepunt-pin —
// een watch beslaat vaak een groot gebied (meerdere staten), dus een pin
// alleen geeft een misleidend beeld van waar/hoe groot het precies is. Elke
// andere/geen selectie ruimt de vorige omtrek gewoon op. Meerdere ringen
// (zelden: een MultiPolygon) worden als losse vormen getekend, niet als
// gaten in één vorm.
// Sinds 2026-08-17 tekent dezelfde functie ook de NHC-voorspelde-koers voor
// orkanen, indien aanwezig: `detail.gebiedPolygon` hergebruikt de bestaande
// "cone of uncertainty"-polygon-tekening hierboven (identiek mechanisme,
// andere databron), en `detail.koerslijn` (nieuw) is de voorspelde-koerslijn
// zelf — getekend als losse polylijn in dezelfde gebiedLaag, zodat 'm gewoon
// meetelt in fitBounds() zonder extra code daarvoor.
// Retourneert de gebiedLaag (voor fitBounds) of null als er niks te tekenen was.
function toonGebiedVoor(signal) {
  if (!gebiedLaag) return null;
  gebiedLaag.clearLayers();
  const ringenLatLon = signal.detail?.gebiedPolygon;
  const koerslijnLatLon = signal.detail?.koerslijn;
  let ietsGetekend = false;
  if (Array.isArray(ringenLatLon) && ringenLatLon.length) {
    ringenLatLon.forEach((ring) => {
      L.polygon(ring, {
        className: 'gebied-omtrek',
        color: '#ff2e6d',
        weight: 1.5,
        opacity: 0.55,
        dashArray: '5 7',
        fillColor: '#ff2e6d',
        fillOpacity: 0.05,
        interactive: false,
      }).addTo(gebiedLaag);
    });
    ietsGetekend = true;
  }
  if (Array.isArray(koerslijnLatLon) && koerslijnLatLon.length >= 2) {
    L.polyline(koerslijnLatLon, {
      className: 'koers-lijn',
      color: '#3ec6ff',
      weight: 2.5,
      opacity: 0.85,
      dashArray: '2 6',
      interactive: false,
    }).addTo(gebiedLaag);
    ietsGetekend = true;
  }
  return ietsGetekend ? gebiedLaag : null;
}

// Wordt bij elke reguliere 20-seconden-verversing aangeroepen (zie renderMap)
// zodat een gebied-omtrek (watch aangepast/verlopen) meebeweegt zolang je 'm
// openhoudt — zonder de kaartweergave zelf te verstoren (geen herhaalde
// fitBounds, alleen de vorm wordt opnieuw getekend). Verdwijnt het signaal
// uit de lijst (bv. de watch is verlopen), dan ruimt dit de omtrek netjes op.
function ververGeselecteerdGebied(signalen) {
  if (!geselecteerdGebiedId) return;
  const actueel = signalen.find((s) => s.id === geselecteerdGebiedId);
  if (actueel) {
    toonGebiedVoor(actueel);
  } else {
    gebiedLaag?.clearLayers();
    geselecteerdGebiedId = null;
  }
}

// Bij een aangetikt onweercomplex: de losse flitsen erachter tonen (i.p.v.
// alleen de ene complex-marker) — geeft een gevoel van de vorm/omvang van de
// bui, niet alleen een punt. Elke andere/geen selectie ruimt de vorige set
// gewoon op. Verse flitsen (net binnen) worden feller getekend dan oude
// (tegen het einde van het 30-minuten-venster), via secondenGeleden.
function toonFlitsenVoor(signal) {
  if (!flitsenLaag) return;
  flitsenLaag.clearLayers();
  if (signal.categorie !== 'onweercomplex' || !Array.isArray(signal.detail?.flitsen)) return;
  const VENSTER_SEC = 30 * 60;
  signal.detail.flitsen.forEach((f) => {
    const frisFactor = Math.max(0, 1 - (f.secondenGeleden ?? VENSTER_SEC) / VENSTER_SEC);
    L.circleMarker([f.lat, f.lon], {
      className: 'flits-punt',
      radius: 3,
      color: '#ffd166',
      weight: 1,
      opacity: 0.35 + frisFactor * 0.5,
      fillColor: '#ffd166',
      fillOpacity: 0.2 + frisFactor * 0.55,
      interactive: false,
    }).addTo(flitsenLaag);
  });
}

// Wordt bij elke reguliere 20-seconden-verversing aangeroepen (zie renderMap)
// zodat nieuwe flitsen vanzelf bijkomen zolang je een onweercomplex openstaat
// — zonder dat je opnieuw hoeft te tikken. Verdwijnt het complex uit de
// signalenlijst (te weinig flitsen meer over binnen het venster), dan ruimt
// dit de laag netjes op i.p.v. verouderde stipjes te laten hangen.
function ververGeselecteerdeFlitsen(signalen) {
  if (!geselecteerdComplexId) return;
  const actueel = signalen.find((s) => s.id === geselecteerdComplexId);
  if (actueel) {
    toonFlitsenVoor(actueel);
  } else {
    flitsenLaag?.clearLayers();
    geselecteerdComplexId = null;
  }
}

// Regenradar via RainViewer — gratis, geen sleutel, bedoeld voor
// persoonlijk/educatief gebruik. https://www.rainviewer.com/api.html
// Let op: dit is neerslagradar (grondstations), GEEN wolkenfoto — boven open
// oceaan (waar geen radarstation staat) blijft dit dus leeg. Voor wolken
// overal ter wereld is de aparte Satelliet-laag (NASA GIBS/GOES) bedoeld.
// Een lus van de laatste ~2 uur (radar.past) plus de nowcast-voorspelling
// (radar.nowcast, indien beschikbaar), die je met ▶ kunt afspelen.
// Dubbel gebufferd (twee lagen, 'a' en 'b') i.p.v. één laag + setUrl(): met
// één laag gooit Leaflet bij setUrl() meteen alle tegels van die laag leeg en
// laadt ze opnieuw, wat tijdens Play elke ~1200ms een zichtbare lege flits
// gaf. Nu laden we het volgende frame onzichtbaar (opacity 0) in de andere
// laag, en pas als díe helemaal klaar is (Leaflet's 'load'-event) faden we
// over — de zichtbare laag verdwijnt precies op het moment dat de nieuwe er
// al staat, dus geen gat meer.
let radarLagen = null; // { a: L.TileLayer, b: L.TileLayer } zodra aangemaakt
let radarActief = 'a'; // welke van de twee momenteel zichtbaar is (opacity 0.6)
let radarLaadTeller = 0; // race-guard: negeer een 'load' die niet meer bij het laatst-aangevraagde frame hoort
let radarFrames = []; // [{time, path}], gesorteerd oud → nieuw (incl. voorspelling)
let radarNuIndex = 0; // grens tussen verleden en voorspelling, voor de tijd-label
let radarIndex = 0;
let radarSpelend = false;
let radarTimer = null;
let radarFramesOpgehaald = false;

// 2026-08-19: tegels lopen nu via de eigen backend (/api/regenradar/..., zie
// server.js) i.p.v. rechtstreeks naar tilecache.rainviewer.com — Lex zag flink
// geflikker (afwisselend goede tegels en een "niet beschikbaar"-plaatje), en
// RainViewer's eigen responsheaders lieten X-Ratelimit-* zien: een reëel
// snelheidslimiet, waarschijnlijk aangetikt door al het herladen/testen
// tijdens deze sessie. De backend cachet elke tegel nu een uur, dus dezelfde
// tegel wordt niet telkens opnieuw bij RainViewer opgehaald. radarHost (uit
// weather-maps.json) is hierdoor niet meer nodig — het pad zelf (frame.path)
// bevat alle info die de proxy nodig heeft.
function frameUrl(frame) {
  return `/api/regenradar${frame.path}/256/{z}/{x}/{y}/2/1_1.png`;
}

// Geeft een Promise terug die pas resolvet zodra de nieuwe tegels
// daadwerkelijk klaar zijn (of na RADAR_LAAD_TIMEOUT_MS, als vangnet tegen
// een kapotte/hangende tegel) — de afspeel-lus hieronder wacht hierop vóór
// hij aan het volgende frame begint, i.p.v. op een vaste klok door te tikken.
const RADAR_LAAD_TIMEOUT_MS = 4000;

function toonRadarFrame(index) {
  if (!radarFrames.length) return Promise.resolve();
  radarIndex = ((index % radarFrames.length) + radarFrames.length) % radarFrames.length;
  const frame = radarFrames[radarIndex];
  const label = new Date(frame.time * 1000).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
  RADAR_TIJD_EL.textContent = radarIndex < radarNuIndex ? label : radarIndex === radarNuIndex ? `${label} · nu` : `${label} · verwacht`;

  if (!radarLagen) {
    // Eerste keer: nog niets op de kaart, dus geen crossfade nodig — 'b'
    // start met dezelfde tegels als 'a' (alleen onzichtbaar) zodat 'ie geen
    // lege URL hoeft te laden zodra initRadar() 'm aan de kaart toevoegt.
    const opties = { attribution: 'Regenradar: RainViewer', maxZoom: 12, pane: 'radarPane' };
    radarLagen = {
      a: L.tileLayer(frameUrl(frame), { ...opties, opacity: 0.6 }),
      b: L.tileLayer(frameUrl(frame), { ...opties, opacity: 0 }),
    };
    radarActief = 'a';
    return Promise.resolve();
  }

  const zichtbaar = radarLagen[radarActief];
  const onzichtbaar = radarLagen[radarActief === 'a' ? 'b' : 'a'];
  const dezeAanvraag = ++radarLaadTeller;
  return new Promise((resolve) => {
    let klaar = false;
    const afronden = () => {
      if (klaar) return;
      klaar = true;
      if (dezeAanvraag === radarLaadTeller) {
        // Alleen wisselen als er ondertussen niet alweer een nieuwer frame is
        // aangevraagd — anders zou een trage, inmiddels-overbodige lading
        // alsnog een stap terug in de tijd laten zien.
        onzichtbaar.setOpacity(0.6);
        zichtbaar.setOpacity(0);
        radarActief = radarActief === 'a' ? 'b' : 'a';
      }
      resolve();
    };
    onzichtbaar.once('load', afronden);
    setTimeout(afronden, RADAR_LAAD_TIMEOUT_MS); // vangnet: nooit voorgoed blijven hangen op één trage/kapotte tegel
    onzichtbaar.setUrl(frameUrl(frame));
  });
}

// ---- Afspelen: zelf-plannende lus i.p.v. een vaste setInterval, 2026-08-19 -
// Root cause van het "schokkerige" gevoel dat Lex meldde: de oude
// setInterval(…, 1200) tikte op de klok door, ook als de vorige tegels nog
// niet binnen waren. toonRadarFrame() negeerde die nog-lopende lading dan via
// de race-guard (dezeAanvraag !== radarLaadTeller) — het frame werd dus
// gewoon stilzwijgend NIET getoond i.p.v. vertraagd. Bij wisselende laadtijd
// (bijv. de eerste keer door alle frames heen, cache-miss richting
// RainViewer) gaf dat een onvoorspelbare, hortende afspeelsnelheid: sommige
// frames wel, andere niet zichtbaar, ondanks een keurig vast interval.
// Fix: elke stap wácht nu eerst op de Promise van toonRadarFrame() (dus
// daadwerkelijk klaar, of de timeout-vangnet hierboven) en plant pas dan de
// volgende stap na RADAR_STAP_MS — gegarandeerd elk frame in beeld, op de
// kosten van een iets minder metronomisch strak tempo bij een trage tegel
// (beter een moment iets langer stilstaan dan een frame overslaan).
const RADAR_STAP_MS = 1200;

function radarSpeelStap() {
  if (!radarSpelend) return;
  toonRadarFrame(radarIndex + 1).then(() => {
    if (!radarSpelend) return;
    radarTimer = setTimeout(radarSpeelStap, RADAR_STAP_MS);
  });
}

function radarAfspelenStart() {
  radarSpelend = true;
  RADAR_SPEEL_EL.textContent = '⏸';
  radarSpeelStap();
}

function radarAfspelenStop() {
  radarSpelend = false;
  RADAR_SPEEL_EL.textContent = '▶';
  clearTimeout(radarTimer);
}

// ---- Satellietbeeld (NASA GIBS, GOES GeoColor), 2026-08-18 -----------------
// Op verzoek van Lex: hij zag terecht geen bewolking op de wolkenfilm (Rain-
// Viewer) bij een storm midden op de oceaan — RainViewer is een mozaïek van
// GROND-radars (zie rainviewer.com/coverage.html), en die dekken de open
// oceaan simpelweg niet, hoe hevig de storm daar ook is. NASA GIBS levert
// near-real-time (10 min, ~40 min vertraging) GOES-GeoColor-tegels die WEL
// overal dekking geven (satellietbeeld i.p.v. grondradar) — gratis, geen
// sleutel.
//
// Twee bugs achter elkaar gevonden en gefixt (2026-08-18), beide dankzij Lex
// die zelf de Netwerk-tab/Worldview heeft uitgeplozen toen de laag leeg bleef:
// 1) bestandsformaat was .jpg gegokt, moest .png zijn (uit de capabilities-XML).
// 2) de "nette" RESTful tegel-URL uit diezelfde capabilities-XML bleek voor
//    deze specifieke laag ("v0 NRT", nog beta binnen GIBS) in de praktijk niet
//    te werken (consequent 404, ook na de .png-fix) — pas door een écht
//    werkende tegel-request van NASA's eigen Worldview-tool na te bootsen
//    (Netwerk-tab van worldview.earthdata.nasa.gov) bleek dat deze laag alleen
//    via het oudere KVP-endpoint (wmts.cgi met querystring-parameters)
//    bediend wordt, niet via het REST-pad-endpoint. Worldview gebruikt daar-
//    voor zelf epsg4326 (lengte/breedtegraad), maar epsg3857 (Web Mercator,
//    wat onze kaart al gebruikt) + KVP bleek ook gewoon te werken — dus geen
//    projectie-ombouw nodig, alleen een andere manier van URL's opbouwen.
let satellietLagen = null; // { oost, west } | null
let satellietActief = false;

// Basisbuffer: hoe ver "nu" standaard terug wordt gezet vóór het afronden op
// het laatste 10-minutenblok. Live bevestigd (2026-08-18, via Lex' eigen
// tests): het "best"-endpoint snapt GEEN te recent tijdstip terug naar het
// nieuwste beschikbare frame — een tijdstip van een paar minuten geleden gaf
// gewoon een 404 ("nog niet gepubliceerd"), terwijl exact dezelfde tegel met
// een tijdstip van ~45 minuten terug wél een plaatje gaf. Past bij de ~40 min
// verwerkingsvertraging van deze near-real-time data.
const SATELLIET_BASIS_BUFFER_MIN = 45;

function satellietTijdMetExtraBuffer(extraMinutenTerug) {
  const nu = new Date(Date.now() - (SATELLIET_BASIS_BUFFER_MIN + extraMinutenTerug) * 60 * 1000);
  nu.setUTCMinutes(Math.floor(nu.getUTCMinutes() / 10) * 10, 0, 0);
  return nu.toISOString().replace(/\.\d+Z$/, 'Z');
}

function satellietTijd() {
  return satellietTijdMetExtraBuffer(0);
}

// Losse, "kale" tegel-URL (geen {s}/{z}/{x}/{y}-templateplaatshouders zoals
// satellietUrl() hieronder) — gebruikt door de herpoging-logica in
// toggleSatelliet() om één specifieke mislukte tegel opnieuw op te vragen met
// een ander tijdstip, zonder de hele laag opnieuw te laten opbouwen.
function satellietTegelUrl(laagId, tijdIso, z, x, y) {
  const sub = SATELLIET_SUBDOMEINEN[(x + y) % SATELLIET_SUBDOMEINEN.length];
  return (
    `https://gibs-${sub}.earthdata.nasa.gov/wmts/epsg3857/best/wmts.cgi?` +
    `TIME=${tijdIso}&layer=${laagId}&style=default&tilematrixset=GoogleMapsCompatible_Level7` +
    `&Service=WMTS&Request=GetTile&Version=1.0.0&Format=image%2Fpng&TileMatrix=${z}&TileCol=${x}&TileRow=${y}`
  );
}

const SATELLIET_SUBDOMEINEN = ['a', 'b', 'c'];

function satellietUrl(laagId) {
  // KVP-stijl (wmts.cgi?...), epsg3857 + GoogleMapsCompatible_Level7 — live
  // bevestigd werkend op 2026-08-18 (zie commentaar hierboven). {s} laat
  // Leaflet over de gibs-a/-b/-c subdomeinen verdelen (net als NASA Worldview
  // zelf doet), {z}/{x}/{y} vult Leaflet automatisch in per tegel.
  return (
    `https://gibs-{s}.earthdata.nasa.gov/wmts/epsg3857/best/wmts.cgi?` +
    `TIME=${satellietTijd()}&layer=${laagId}&style=default&tilematrixset=GoogleMapsCompatible_Level7` +
    `&Service=WMTS&Request=GetTile&Version=1.0.0&Format=image%2Fpng&TileMatrix={z}&TileCol={x}&TileRow={y}`
  );
}

// ---- Herpoging per losse tegel, 2026-08-18 ----------------------------------
// Op verzoek van Lex: hij zag structureel grijze gaten/vlekken op de
// satellietlaag, terwijl referentietools (NASA Worldview) daar wél volledige
// dekking tonen. Root cause (bevestigd via zijn eigen Netwerk-tab): niet elke
// tegel is op exact hetzelfde moment "af" — bij het ene, vaste tijdstip dat
// de hele laag gebruikt, kan tegel A allang gepubliceerd zijn terwijl tegel B
// (net een ander stukje van de scan) nog niet klaar is. Vandaar: bij een
// mislukte tegel niet meteen opgeven, maar een paar keer opnieuw proberen met
// een steeds ouder tijdstip (dat IS zo goed als zeker al gepubliceerd). Het
// aantal en de stapgrootte zijn een redelijke inschatting, niet live per stap
// geverifieerd — in het slechtste geval blijft een tegel na alle pogingen
// alsnog leeg (zelfde nette fallback als voorheen), nooit een kapot plaatje.
const SATELLIET_MAX_HERPOGINGEN = 3;
const SATELLIET_HERPOGING_STAP_MIN = 15;

function satellietTegelHerpogen(laagId) {
  return function (event) {
    const tegel = event.tile;
    const poging = Number(tegel.dataset.satellietPoging || 0);
    if (poging >= SATELLIET_MAX_HERPOGINGEN) return; // definitief opgeven — tegel blijft leeg, geen crash
    const nieuwePoging = poging + 1;
    tegel.dataset.satellietPoging = String(nieuwePoging);
    const { x, y, z } = event.coords;
    // event.coords is de RAUWE, nog niet "om de wereld heen gewrapte" tegel-
    // coördinaat (Leaflet past die wrap normaal gesproken zelf toe vlak vóór
    // het opbouwen van de tegel-URL, iets wat we hier handmatig overdoen omdat
    // we niet Leaflet's eigen getTileUrl() gebruiken). Zonder deze correctie
    // kreeg een tegel voorbij de datumgrens (x negatief of ≥ 2^z) een
    // ongeldige TileCol mee — bleek uit een 400-foutmelding i.p.v. de
    // verwachte 404, gevonden dankzij Lex' eigen Netwerk-tab-check.
    const kolommenOpDitNiveau = 2 ** z;
    const xGewrapt = ((x % kolommenOpDitNiveau) + kolommenOpDitNiveau) % kolommenOpDitNiveau;
    const tijd = satellietTijdMetExtraBuffer(nieuwePoging * SATELLIET_HERPOGING_STAP_MIN);
    tegel.src = satellietTegelUrl(laagId, tijd, z, xGewrapt, y);
  };
}

// ---- EUMETSAT Meteosat (MTG), 0° lengtegraad — 2026-08-19 -------------------
// GOES-East houdt ergens rond Frankrijk op (rand van het zichtbare schijfje
// van die satelliet), dus Europa/Afrika/Midden-Oosten bleven zonder wolken-
// dekking. EUMETSAT publiceert zelf een gratis WMS voor hun nieuwe MTG-
// satelliet (Meteosat Third Generation, boven de evenaar op 0°) — dit is GEEN
// NASA GIBS/WMTS-laag zoals GOES, maar een heel andere dienst: een eigen
// GeoServer-WMS op view.eumetsat.int. Gevonden via Lex' eigen Netwerk-tab-
// check in NASA Worldview. Leaflet's L.tileLayer.wms bouwt zelf per tegel de
// juiste BBOX-URL op (geen handmatige {z}/{x}/{y}-template nodig zoals bij de
// GIBS-lagen), en tilet nog steeds gewoon 256x256 zoals een normale laag.
// Onbevestigd/nog niet live getest: (1) of deze server tegels in epsg3857
// (Web Mercator, wat onze kaart gebruikt) teruggeeft — Worldview zelf vroeg
// in epsg4326 op; (2) de publicatievertraging van dit product (20 minuten
// hieronder is een voorzichtige eerste inschatting op basis van de
// 10-minuten-cadans, geen bevestigde meting zoals bij GOES). Bijstellen zodra
// Lex een lege/foutieve laag ziet — zelfde aanpak als bij de GOES-bugs.
const EUMETSAT_WMS_URL = 'https://view.eumetsat.int/geoserver/wms';
const EUMETSAT_LAAG_ID = 'mtg_fd:rgb_geocolour';
const EUMETSAT_BUFFER_MIN = 20;

function eumetsatTijd() {
  const nu = new Date(Date.now() - EUMETSAT_BUFFER_MIN * 60 * 1000);
  nu.setUTCMinutes(Math.floor(nu.getUTCMinutes() / 10) * 10, 0, 0);
  return nu.toISOString().replace(/\.\d+Z$/, 'Z');
}

function toggleSatelliet() {
  satellietActief = !satellietActief;
  TOGGLE_SATELLIET_EL.classList.toggle('actief', satellietActief);
  if (!satellietActief) {
    if (satellietLagen) {
      kaart.removeLayer(satellietLagen.oost);
      kaart.removeLayer(satellietLagen.west);
      kaart.removeLayer(satellietLagen.eumetsat);
    }
    return;
  }
  if (!satellietLagen) {
    // minNativeZoom = maxNativeZoom = 6: deze "v0 NRT"-bètalaag blijkt in de
    // praktijk alleen tegels te hebben op het hoogste detailniveau (zoom 6) —
    // geen kant-en-klare lagere overzichtsniveaus zoals normale kaartlagen.
    // Bevestigd via Lex' eigen Netwerk-tab: op zoom 4 gaven ALLE tegels 404,
    // ook tegels die middenin beeld vielen (dus niet zomaar "buiten dekking").
    // Door minNativeZoom ook op 6 te zetten, vraagt Leaflet op élk zoomniveau
    // altijd de zoom-6-tegels op en vergroot die zelf (iets korreliger bij ver
    // uitzoomen, maar wél zichtbaar) in plaats van niet-bestaande lagere
    // niveaus op te vragen.
    const opties = {
      pane: 'satellietPane',
      opacity: 0.75,
      minNativeZoom: 6,
      maxNativeZoom: 6,
      subdomains: ['a', 'b', 'c'],
      attribution: 'Satelliet: NASA GIBS/GOES',
    };
    satellietLagen = {
      oost: L.tileLayer(satellietUrl('GOES-East_ABI_GeoColor'), opties),
      west: L.tileLayer(satellietUrl('GOES-West_ABI_GeoColor'), opties),
      eumetsat: L.tileLayer.wms(EUMETSAT_WMS_URL, {
        layers: EUMETSAT_LAAG_ID,
        format: 'image/png',
        transparent: true,
        version: '1.3.0',
        uppercase: true, // zodat de query-string TIME=/LAYERS=/FORMAT= gebruikt, zoals bevestigd in Lex' Netwerk-tab
        time: eumetsatTijd(),
        pane: 'satellietPane',
        opacity: 0.75,
        attribution: 'Satelliet: EUMETSAT MTG',
      }),
    };
    satellietLagen.oost.on('tileerror', satellietTegelHerpogen('GOES-East_ABI_GeoColor'));
    satellietLagen.west.on('tileerror', satellietTegelHerpogen('GOES-West_ABI_GeoColor'));
    // Nog geen herpoging-per-tegel voor EUMETSAT: dat is een heel ander
    // (WMS/BBOX-)URL-schema dan de GIBS-tegel-URL's, dus satellietTegelHerpogen
    // hierboven is er niet direct op toepasbaar. Eerst even zien of dit
    // probleem hier überhaupt optreedt vóór we die complexiteit toevoegen.
  }
  satellietLagen.oost.addTo(kaart);
  satellietLagen.west.addTo(kaart);
  satellietLagen.eumetsat.addTo(kaart);
}

// Was voorheen alleen onderdeel van wisselWeergave(true) ("Weer"-stand) —
// die aparte stand is op 2026-08-18 weggehaald (deed toch niks anders dan
// deze balk tonen/verbergen), dus deze laadt nu meteen bij het opstarten van
// de kaart. Radar/Satelliet zijn sindsdien onafhankelijke, altijd-zichtbare
// bediening, los van welke gevaren-iconen je ziet.
async function initRadar() {
  if (!radarFramesOpgehaald) {
    radarFramesOpgehaald = true; // niet opnieuw proberen als het één keer faalt
    try {
      const data = await fetch('https://api.rainviewer.com/public/weather-maps.json').then((r) => r.json());
      const verleden = data.radar?.past ?? [];
      const voorspelling = data.radar?.nowcast ?? [];
      radarFrames = [...verleden, ...voorspelling];
      radarNuIndex = verleden.length - 1;
    } catch (err) {
      console.error('[weer] wolkenfilm kon niet geladen worden:', err);
    }
  }

  if (!radarFrames.length) return;
  toonRadarFrame(radarNuIndex); // start bij "nu", niet bij het oudste frame
  radarLagen.a.addTo(kaart);
  radarLagen.b.addTo(kaart);
  // Niet automatisch laten afspelen — dat voelde als een storend "flitsend"
  // beeld direct bij het openen van de app. Gewoon het huidige moment
  // statisch tonen; ▶ start de lus pas op eigen verzoek.
}

// 2026-08-19: aan/uit-knop voor de regenradar. Stond hier tijdelijk standaard
// UIT tijdens het "Zoom Level Not Supported"-debugtraject (zie het uitgebreide
// verslag in het architectuurdocument) — inmiddels is de root cause gevonden
// en gefixt (RainViewer-rate-limiting, opgelost met een eigen gecachte
// backend-proxy + trager afspelen + placeholder-vervanging), dus die
// voorzichtigheid is niet meer nodig. Terug naar standaard AAN — Lex hoefde
// hier niet meer zelf op te klikken; de knop blijft gewoon als handmatige
// noodschakelaar beschikbaar.
let regenradarAan = true;

function toggleRegenradar() {
  regenradarAan = !regenradarAan;
  TOGGLE_REGENRADAR_EL.classList.toggle('actief', regenradarAan);
  if (regenradarAan) {
    initRadar();
  } else {
    radarAfspelenStop();
    if (radarLagen) {
      kaart.removeLayer(radarLagen.a);
      kaart.removeLayer(radarLagen.b);
    }
    RADAR_TIJD_EL.textContent = '—';
  }
}

// Aparte, kortere titel + een gedempte detailregel eronder — voorkomt dat
// bijv. een landenlijst bij een grote cycloon de hele titel dichtslibt (zie
// gdacs.js: de titel zelf blijft kort, de volledige lijst zit in detail.land).
function popupHtml(s) {
  const detailregel = s.detail?.land ?? s.detail?.subtitel ?? s.detail?.gebied ?? null;
  return `<div class="popup-titel">${s.titel}</div>${detailregel ? `<div class="popup-sub">${detailregel}</div>` : ''}${popupExtraHtml(s)}`;
}

// Simpele HTML-escape voor tekst die in een attribuut (title="...") belandt —
// voorkomt dat een aanhalingsteken in een Reddit-posttitel de markup breekt.
function escapeAttr(tekst) {
  return String(tekst ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;');
}

// Extra popup-inhoud per categorie — plaatjes, statregels, links. Bewust hier
// gecentraliseerd i.p.v. verspreid, zodat één blik op deze functie laat zien
// welke categorieën welke verrijking tonen. Elk blok is onafhankelijk: mist
// een veld (nog niet geladen/nooit geverifieerd/best-effort mislukt), dan
// verschijnt dat ene blokje simpelweg niet — de rest van de popup blijft
// intact. Een <img> die niet laadt (bijv. een verkeerd gegokte satelliet-
// sectorcode) verwijdert zichzelf via onerror i.p.v. een kapot-plaatje-icoon
// te tonen.
function popupExtraHtml(s) {
  const d = s.detail ?? {};
  const blokken = [];

  if (s.categorie === 'orkaan') {
    const stats = [];
    if (d.windKt != null) stats.push(`${Math.round(d.windKt)} kt wind`);
    if (d.drukHpa != null) stats.push(`${Math.round(d.drukHpa)} hPa`);
    if (stats.length) blokken.push(`<div class="popup-stats">${stats.join(' · ')}</div>`);
    // Los statisch STAR CDN-satellietplaatje hier is op 2026-08-18 weggehaald
    // op verzoek van Lex ("valt uit beeld, meer last dan gemak, overkill") —
    // nu de interactieve GIBS-kaartlaag (zie 🛰️ Satelliet-knop) gewoon goed
    // werkt, was dit vaste plaatje overbodig geworden.
    if (d.communityFotos?.length) blokken.push(popupFotostripHtml(d.communityFotos));
    if (d.stormSurgeTekst) blokken.push(`<div class="popup-surge">🌊 ${d.stormSurgeTekst}</div>`);
    if (d.adviesTekst) {
      const kort = d.adviesTekst.length > 220 ? `${d.adviesTekst.slice(0, 220)}…` : d.adviesTekst;
      blokken.push(`<div class="popup-advies">${kort}</div>`);
    }
    if (d.publicAdvisoryUrl) {
      blokken.push(`<a class="popup-link" href="${d.publicAdvisoryUrl}" target="_blank" rel="noopener">Volledige advisory op nhc.gov →</a>`);
    }
  }

  if (s.categorie === 'aardbeving') {
    const stats = [];
    if (d.magnitude != null) stats.push(`M${d.magnitude}`);
    if (d.diepteKm != null) stats.push(`${d.diepteKm}km diep`);
    if (d.afstandTotJouKm != null) stats.push(`${d.afstandTotJouKm}km van jou`);
    if (stats.length) blokken.push(`<div class="popup-stats">${stats.join(' · ')}</div>`);
    if (d.shakemapUrl) {
      blokken.push(`<img class="popup-foto" src="${d.shakemapUrl}" alt="ShakeMap" loading="lazy" onerror="this.remove()">`);
    }
    if (d.bronUrl) blokken.push(`<a class="popup-link" href="${d.bronUrl}" target="_blank" rel="noopener">Meer info op usgs.gov →</a>`);
  }

  if (s.categorie === 'cycloonvorming' && d.kansTekst) {
    blokken.push(`<div class="popup-stats">${d.kansTekst}</div>`);
  }

  return blokken.length ? `<div class="popup-extra">${blokken.join('')}</div>` : '';
}

// Kleine foto-strip voor ongemodereerde community-foto's (Reddit) — altijd
// met een expliciet "community, ongecontroleerd"-label, zodat dit nooit
// aanziet voor officieel NOAA-beeldmateriaal. Elke foto linkt door naar de
// oorspronkelijke Reddit-post i.p.v. alleen een los plaatje te tonen.
function popupFotostripHtml(fotos) {
  const items = fotos
    .map(
      (f) =>
        `<a href="${f.link}" target="_blank" rel="noopener" title="${escapeAttr(f.titel)}"><img src="${f.thumbUrl ?? f.url}" alt="Communityfoto" loading="lazy" onerror="this.closest('a').remove()"></a>`
    )
    .join('');
  return `<div class="popup-fotostrip">${items}</div><div class="popup-fotostrip-label">📷 community, ongecontroleerd</div>`;
}

// Lifeliner (traumahelikopter) krijgt een eigen geel icoon i.p.v. de
// generieke 🚨/ernst-kleur van de rest van de hulpdiensten-categorie, op
// verzoek van Lex — een helikopter in de lucht is heel anders te herkennen
// dan een grondgebonden uitruk, dat mag ook zo ogen. `is-lifeliner` vervangt
// de ernst-klasse (i.p.v. ernaast) zodat de vaste gele kleur niet per ongeluk
// weer overschreven wordt door een ernst-kleurregel.
function isLifeliner(s) {
  return s.categorie === 'hulpdiensten' && s.detail?.discipline === 'lifeliner';
}

// Handgetekende silhouet-helikopter (rotor/mast/romp/staartboom/staartrotor/
// skids), allemaal in dezelfde gele kleur gevuld — het 🚁-emoji zelf kan geen
// eigen kleur krijgen (is een vast gekleurde glyph, geen monochrome/CSS-
// kleurbare vorm), vandaar een eigen SVG i.p.v. de emoji, puur voor Lifeliner.
const LIFELINER_HELI_SVG = `
  <svg viewBox="0 0 24 24" width="18" height="18" xmlns="http://www.w3.org/2000/svg">
    <rect x="2" y="5.2" width="20" height="1.4" rx="0.7" fill="#ffd633"/>
    <rect x="11.3" y="6.5" width="1.4" height="2.2" fill="#ffd633"/>
    <ellipse cx="11" cy="13" rx="5.5" ry="3.6" fill="#ffd633"/>
    <rect x="15.5" y="12.2" width="6" height="1.6" rx="0.6" fill="#ffd633"/>
    <rect x="20.4" y="9.5" width="1.3" height="5" fill="#ffd633"/>
    <line x1="8" y1="16.4" x2="8" y2="19.3" stroke="#ffd633" stroke-width="1.3" stroke-linecap="round"/>
    <line x1="14" y1="16.4" x2="14" y2="19.3" stroke="#ffd633" stroke-width="1.3" stroke-linecap="round"/>
    <line x1="5.5" y1="19.3" x2="16.5" y2="19.3" stroke="#ffd633" stroke-width="1.3" stroke-linecap="round"/>
  </svg>
`.trim();

function hazardIconHtml(s) {
  return isLifeliner(s) ? LIFELINER_HELI_SVG : (EMOJI_PER_CATEGORIE[s.categorie] ?? '•');
}

function renderMap(signalen) {
  if (!kaart) return; // wacht tot initMap() is geweest
  signaalLaag.clearLayers();
  markersPerId.clear();
  signalen
    .filter((s) => s.lat != null && s.lon != null)
    .forEach((s) => {
      // Gevlogen spoor eerst tekenen (onder de marker) — zelf opgebouwd door
      // de backend sinds die 'm is gaan volgen (geen historie van vóór het
      // opstarten), zie detail.route in sources/lifeliner.js. Dunne gele lijn,
      // zelfde kleur als het helikoptertje zelf.
      if (isLifeliner(s) && Array.isArray(s.detail?.route) && s.detail.route.length >= 2) {
        L.polyline(s.detail.route, {
          color: '#ffd633',
          weight: 2.5,
          opacity: 0.65,
          dashArray: '1,6',
          lineCap: 'round',
        }).addTo(signaalLaag);
      }

      const pinKlasse = isLifeliner(s) ? 'is-lifeliner' : `ernst-${s.ernst}`;
      const icon = L.divIcon({
        className: '',
        html: `<div class="hazard-pin ${pinKlasse}">${hazardIconHtml(s)}</div>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15],
      });
      const popupBreedte = POPUP_BREED_CATEGORIEEN.has(s.categorie) ? 300 : 240;
      const marker = L.marker([s.lat, s.lon], { icon })
        .addTo(signaalLaag)
        .bindPopup(popupHtml(s), { maxWidth: popupBreedte });
      markersPerId.set(s.id, marker);
    });
  // Geen eigen ververs-lus voor de flitsenstippen/gebied-omtrek — beide
  // liften mee op dezelfde 20-seconden-cyclus die renderMap() toch al elke
  // keer met verse data aanroept (zie verversen()).
  ververGeselecteerdeFlitsen(signalen);
  ververGeselecteerdGebied(signalen);
}

// ---- Meldingen-lijst (vervangt de horizontale sleepbalk) --------------
// Groepeert per categorie en toont daarbinnen alleen de meest urgente/recente
// melding + een "+N meer"-knop voor de rest — zodat bijv. 8 aardbevingen niet
// de hele lijst vullen. Ambient info die al elders staat (Hemel-tab,
// weerkaartje) wordt hier helemaal niet getoond.
let laatsteMeldingenSignalen = [];
let uitgeklapteCategorieen = new Set();

function sorteerOpErnstEnTijd(a, b) {
  const p = (ERNST_PRIORITEIT[a.ernst] ?? 9) - (ERNST_PRIORITEIT[b.ernst] ?? 9);
  return p !== 0 ? p : new Date(b.tijd ?? 0) - new Date(a.tijd ?? 0);
}

// Items binnen een categorie sorteren — voor de meeste categorieën blijft dat
// ernst-dan-recentheid, maar onweercomplexen zijn juist het duidelijkst
// geordend op afstand (dichtbij eerst): de Blitzortung-connector levert die
// afstand al mee in detail.afstandKm.
function sorteerItemsInCategorie(cat, items) {
  if (cat === 'onweercomplex') {
    return [...items].sort((a, b) => (a.detail?.afstandKm ?? Infinity) - (b.detail?.afstandKm ?? Infinity));
  }
  return [...items].sort(sorteerOpErnstEnTijd);
}

function maakMeldingItem(s) {
  const opKaart = s.lat != null && s.lon != null;
  const btn = document.createElement('button');
  // ernst-klasse regelt nu alleen nog opacity (zie styles.css), cat-klasse de
  // randkleur — apart gezet op 2026-08-19 zodat elke categorie een eigen,
  // herkenbare kleur krijgt i.p.v. de vorige ernst-gebaseerde kleur (die was
  // vooral rood/oranje, weinig onderscheidend tussen categorieën).
  btn.className = `melding-item ernst-${s.ernst} cat-${s.categorie}${opKaart ? '' : ' niet-op-kaart'}${s.bron?.haperend ? ' haperend' : ''}`;
  // Geen apart categorie-label meer boven de titel (2026-08-19, weer
  // weggehaald op Lex' verzoek: "Waarom herhaal je dan die titel in de regel
  // eronder") — de titel zelf noemt bij de meeste categorieën de categorie
  // al impliciet ("Vulkaanuitbarsting", "Droogte Uganda", "Onweercomplex"),
  // dus een los label eronder was vooral dubbelop. Categorie blijft wel
  // zichtbaar via het icoon, de randkleur (cat-*) en de "+N meer (cat)"-knop.
  btn.innerHTML = `
    <span class="em">${hazardIconHtml(s)}</span>
    <span class="txt">
      <div class="titel">${s.titel}</div>
      <div class="sub"><span class="tier-dot ${s.bron?.tier ?? 'community'}"></span>${s.bron?.naam ?? ''} · ${geledenTekst(s.bron?.bijgewerkt)}</div>
    </span>
    ${opKaart ? '<span class="chev">›</span>' : ''}
  `;
  if (opKaart) btn.addEventListener('click', () => centreerOpMelding(s));
  return btn;
}

// 2026-08-19, op Lex' verzoek ("Alle categorieën zijn dus altijd in beeld, als
// er bij een cat niets is dan staat dat in de kaart"): een gedimd, niet-
// klikbaar kaartje voor categorieën zonder actieve melding — voorheen
// verdween zo'n categorie gewoon volledig uit de Meldingen-lijst, wat het
// onduidelijk maakte of een rustige categorie ook daadwerkelijk gecheckt was
// (geen data getoond) i.p.v. bewust "niets aan de hand".
function maakLegeMeldingItem(cat) {
  const div = document.createElement('div');
  div.className = `melding-item leeg cat-${cat}`;
  div.innerHTML = `
    <span class="em">${EMOJI_PER_CATEGORIE[cat] ?? '•'}</span>
    <span class="txt">
      <div class="titel">${cat}</div>
      <div class="sub">Geen actieve meldingen</div>
    </span>
  `;
  return div;
}

function renderMeldingen(signalen) {
  laatsteMeldingenSignalen = signalen;
  const relevant = signalen.filter((s) => !MELDINGEN_CATEGORIEEN_UITGESLOTEN.has(s.categorie));

  MELDINGEN_BADGE_EL.style.display = relevant.length ? 'flex' : 'none';
  MELDINGEN_BADGE_EL.textContent = String(relevant.length);

  const perCategorie = {};
  relevant.forEach((s) => (perCategorie[s.categorie] ??= []).push(s));

  // Categorieën met de meest urgente melding bovenaan sorteren.
  const actieveCategorieen = Object.keys(perCategorie).sort((catA, catB) => {
    const meestUrgent = (cat) => [...perCategorie[cat]].sort(sorteerOpErnstEnTijd)[0];
    return sorteerOpErnstEnTijd(meestUrgent(catA), meestUrgent(catB));
  });
  // 2026-08-19, op Lex' verzoek: ALLE bekende categorieën staan altijd in de
  // lijst, ook zonder actieve melding — die kwamen voorheen gewoon niet voor
  // in `perCategorie` en verdwenen dus volledig uit beeld. Lege categorieën
  // komen ná de actieve (urgentie-gesorteerde) categorieën, in de vaste
  // EMOJI_PER_CATEGORIE-volgorde, als gedimd niet-klikbaar kaartje.
  const legeCategorieen = Object.keys(EMOJI_PER_CATEGORIE).filter((cat) => !perCategorie[cat]);
  const categorieen = [...actieveCategorieen, ...legeCategorieen];

  // Geen aparte categorie-kop meer boven elke groep (2026-08-19, op Lex'
  // verzoek: "die grijze namen er tussen lelijk en onnodig extra") — de
  // categorienaam staat weer terug zoals 'ie was, in de "+N meer"-knop zelf,
  // met de ruwe/oorspronkelijke categorie-id (geen "nettere" vertaling).
  MELDINGEN_LIJST_EL.innerHTML = '';
  categorieen.forEach((cat) => {
    if (!perCategorie[cat]) {
      MELDINGEN_LIJST_EL.appendChild(maakLegeMeldingItem(cat));
      return;
    }

    const items = sorteerItemsInCategorie(cat, perCategorie[cat]);
    const [primair, ...rest] = items;

    MELDINGEN_LIJST_EL.appendChild(maakMeldingItem(primair));
    if (!rest.length) return;

    const uitgeklapt = uitgeklapteCategorieen.has(cat);
    const toggle = document.createElement('button');
    toggle.className = 'melding-meer';
    toggle.textContent = uitgeklapt ? '– minder tonen' : `+ ${rest.length} meer (${cat})`;
    toggle.addEventListener('click', () => {
      if (uitgeklapt) uitgeklapteCategorieen.delete(cat);
      else uitgeklapteCategorieen.add(cat);
      renderMeldingen(laatsteMeldingenSignalen);
    });
    MELDINGEN_LIJST_EL.appendChild(toggle);

    if (uitgeklapt) rest.forEach((s) => MELDINGEN_LIJST_EL.appendChild(maakMeldingItem(s)));
  });
}

// Hemel-tab toont alle 'hemel'-signalen als losse kaartjes (maanstand,
// ISS-passages, meteorenzwermen, aurora-kans, ruimteweer-context) i.p.v.
// alleen de maanstand — dat was tot nu toe hardcoded op één kaartje en liet
// de andere bronnen dus onzichtbaar, ook al leverde de backend ze al.
const HEMEL_ICOON_PER_PREFIX = { moon: '🌙', iss: '🛰️', meteors: '☄️', swpc: '🌌', donki: '☀️' };

function hemelIcoon(id) {
  return HEMEL_ICOON_PER_PREFIX[id.split('-')[0]] ?? '✨';
}

// Getekend maanicoon i.p.v. het platte 🌙-emoji — de vorm volgt de echte
// faseFractie (0 = nieuwe maan, 0.5 = volle maan, 1 = weer nieuwe maan) via de
// klassieke "twee bogen"-truc: één ellipsboog voor de terminator (de
// schaduwrand) en één cirkelboog voor de verlichte limb, samen omsluiten ze
// het verlichte deel.
//
// Belangrijk: de zwaairichting van beide bogen moet per kwart maancyclus
// wisselen (niet alleen bij nieuwe/volle maan) — anders komt bijv. bij 19%
// verlicht per ongeluk het omgekeerde (bijna volledig verlichte) oppervlak
// eruit. Numeriek geverifieerd tegen de exacte verlichtingsfractie
// (1-cos(2π·fase))/2 over de hele cyclus, en gecontroleerd dat de sikkel
// vloeiend van kant wisselt (geen sprongen) behalve bij nieuwe maan zelf,
// waar het sikkeltje sowieso onzichtbaar dun is.
function maanPad(faseFractie, r) {
  const rx = Math.abs(Math.cos(faseFractie * 2 * Math.PI)) * r;
  const sweepLimb = faseFractie < 0.5 ? 0 : 1;
  const kwartier = Math.floor(faseFractie * 4) % 4;
  const sweepTerminator = kwartier === 0 || kwartier === 2 ? 1 : 0;
  return `M ${r},0 A ${rx},${r} 0 0 ${sweepTerminator} ${r},${2 * r} A ${r},${r} 0 0 ${sweepLimb} ${r},0 Z`;
}

function maanIconSvg(faseFractie) {
  const r = 16;
  const pad = maanPad(faseFractie ?? 0, r);
  return `<svg width="34" height="34" viewBox="0 0 34 34" class="maan-icoon" aria-hidden="true">
    <circle cx="17" cy="17" r="${r}" fill="#1b2036" stroke="rgba(255,255,255,0.18)" stroke-width="1"></circle>
    <g transform="translate(1,1)"><path d="${pad}" fill="#eef1ff"></path></g>
  </svg>`;
}

function hemelSub(s) {
  const d = s.detail ?? {};
  if (s.id.startsWith('moon')) return `${d.illuminatiePercentage}% verlicht · ${d.wassend ? 'wassend' : 'afnemend'}`;
  if (s.id.startsWith('iss')) return `${d.duurMinuten} min · op in ${d.richtingOp}, onder in ${d.richtingOnder}`;
  if (s.id.startsWith('meteors')) return `ZHR ~${d.zhrPerUur}/uur`;
  if (s.id.startsWith('swpc')) return d.toelichting ?? '';
  if (s.id.startsWith('donki')) return d.samenvatting ?? '';
  return '';
}

function renderSky(signalenPerCategorie) {
  const signalen = [...(signalenPerCategorie['hemel'] ?? [])].sort(sorteerOpErnstEnTijd);

  if (!signalen.length) {
    SKY_LIJST_EL.innerHTML = '';
    HEMEL_LEEG_EL.style.display = 'block';
    return;
  }

  HEMEL_LEEG_EL.style.display = 'none';
  SKY_LIJST_EL.innerHTML = '';
  signalen.forEach((s) => {
    const kaart = document.createElement('div');
    kaart.className = 'sky-card';
    const icoonHtml = s.id.startsWith('moon')
      ? maanIconSvg(s.detail?.faseFractie)
      : `<span class="sky-icoon">${hemelIcoon(s.id)}</span>`;
    kaart.innerHTML = `
      ${icoonHtml}
      <div>
        <div class="t1">${s.titel}</div>
        <div class="t2">${hemelSub(s)}</div>
      </div>
    `;
    SKY_LIJST_EL.appendChild(kaart);
  });
}

const WINDRICHTINGEN = ['N', 'NO', 'O', 'ZO', 'Z', 'ZW', 'W', 'NW'];
function windRichtingTekst(graden) {
  if (graden == null) return '—';
  return WINDRICHTINGEN[Math.round(graden / 45) % 8];
}

function renderWeer(signalenPerCategorie) {
  const weer = (signalenPerCategorie['algemeen-weer'] ?? []).find((s) => s.id === 'openmeteo-nu');
  if (!weer) return;
  const d = weer.detail;

  HEADER_TEMP_EL.textContent = `${Math.round(d.temperatuurC)}°`;

  WEATHER_CARD_EL.style.display = 'block';
  WEER_CONDITIE_EL.textContent = weer.titel;
  WEER_TEMP_EL.textContent = `${Math.round(d.temperatuurC)}°C`;
  WEER_GEVOEL_EL.textContent = `${Math.round(d.gevoelstemperatuurC)}°C`;
  WEER_WIND_EL.textContent = `${Math.round(d.windKmh)} km/u ${windRichtingTekst(d.windRichtingGraden)}`;
  WEER_STOTEN_EL.textContent = d.windstotenKmh != null ? `${Math.round(d.windstotenKmh)} km/u` : '—';
  WEER_VOCHT_EL.textContent = `${Math.round(d.luchtvochtigheidPct)}%`;
  WEER_DRUK_EL.textContent = d.luchtdrukHpa != null ? `${Math.round(d.luchtdrukHpa)} hPa` : '—';
  WEER_BEWOLKING_EL.textContent = d.bewolkingPct != null ? `${Math.round(d.bewolkingPct)}%` : '—';
}

// ---- Tornado-alarm — volledig-scherm rode gloedflits + pop-up + geluid +
// trilling, zodra er een NIEUW tornado-gerelateerd signaal verschijnt (op
// verzoek van Lex: "notificatie zodra er een watch en een tornado ontstaan",
// later uitgebreid met bevestigde touchdowns + severe-outlook: "Ja die
// moeten er absoluut ook komen"). Alle vier VS-tornado-categorieën, dus
// dezelfde set als DOPPLER_CATEGORIEEN hierboven — bewust niet breder dan
// dat: dit zware alarm is voorbehouden aan tornado-gerelateerde signalen,
// niet elke hazard in de app.
const ALARM_CATEGORIEEN = DOPPLER_CATEGORIEEN;

// null = nog niet geïnitialiseerd. Bij de eerste `verversen()` na het laden
// van de app worden de dan al actieve tornado/watch-signalen alleen
// geregistreerd, niet gealarmeerd — anders zou de app bij elke keer openen
// meteen voluit alarmeren voor iets dat allang actief was vóór je 'm opende.
// Pas signalen die daarna verschijnen (nieuwe id's) triggeren het alarm —
// dat is wat "ontstaan" hier betekent.
let gezienAlarmIds = null;
let alarmWachtrij = [];
let alarmPopupOpen = false;
let huidigAlarmSignaal = null;
let audioCtx = null;

function verwerkTornadoAlarm(signalen) {
  const relevant = signalen.filter((s) => ALARM_CATEGORIEEN.has(s.categorie));
  const huidigeIds = new Set(relevant.map((s) => s.id));
  if (gezienAlarmIds === null) {
    gezienAlarmIds = huidigeIds;
    return;
  }
  for (const s of relevant) {
    if (!gezienAlarmIds.has(s.id)) triggerTornadoAlarm(s);
  }
  gezienAlarmIds = huidigeIds;
}

function triggerTornadoAlarm(signal) {
  flitsAlarmGloed();
  laatAlarmGeluidHoren();
  trilAlarm();
  alarmWachtrij.push(signal);
  toonVolgendeAlarmPopup();
}

// CSS-klasse verwijderen-en-opnieuw-toevoegen (i.p.v. alleen toevoegen) forceert
// een reflow, zodat de animatie ook opnieuw start als er kort na elkaar twee
// nieuwe watches/warnings binnenkomen.
function flitsAlarmGloed() {
  ALARM_GLOED_EL.classList.remove('flits');
  void ALARM_GLOED_EL.offsetWidth;
  ALARM_GLOED_EL.classList.add('flits');
}

// Geen los geluidsbestand nodig — een korte drietonige "alarm"-piep,
// zelf opgebouwd met de Web Audio API (~1 seconde totaal). Safari/iOS staat
// geluid pas toe ná een echte gebruikersinteractie met de pagina; vandaar
// ontgrendelAudioContext() hieronder, die één keer op de eerste tik/klik
// ergens in de app een AudioContext klaarzet zodat een later, automatisch
// getriggerd alarm ook echt hoorbaar is.
function ontgrendelAudioContext() {
  if (!audioCtx) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    try {
      audioCtx = new Ctx();
    } catch {
      return;
    }
  }
  if (audioCtx.state === 'suspended') audioCtx.resume();
}
document.addEventListener('pointerdown', ontgrendelAudioContext, { once: true });

function laatAlarmGeluidHoren() {
  ontgrendelAudioContext();
  if (!audioCtx) return; // Web Audio niet beschikbaar, of nog niet ontgrendeld — stil falen, de gloed/pop-up blijven wel werken
  const nu = audioCtx.currentTime;
  const duurPerToon = 0.32;
  const tonen = [1046.5, 784, 1046.5]; // hoog-laag-hoog, herkenbaar als "alarm" i.p.v. een neutrale piep
  tonen.forEach((freq, i) => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'square';
    osc.frequency.value = freq;
    const start = nu + i * duurPerToon;
    gain.gain.setValueAtTime(0, start);
    gain.gain.linearRampToValueAtTime(0.18, start + 0.02);
    gain.gain.linearRampToValueAtTime(0, start + duurPerToon - 0.02);
    osc.connect(gain).connect(audioCtx.destination);
    osc.start(start);
    osc.stop(start + duurPerToon);
  });
}

// Vibration API — werkt op Android/Chrome, bewust geen probleem dat iOS
// Safari 'm niet ondersteunt (Apple biedt 'm niet aan): navigator.vibrate
// ontbreekt dan simpelweg, en deze functie doet dan stil niets.
function trilAlarm() {
  if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 400]);
}

// Pop-up-wachtrij: als er kort na elkaar meerdere nieuwe watches/warnings
// binnenkomen, worden ze één voor één getoond i.p.v. elkaar te overschrijven.
function toonVolgendeAlarmPopup() {
  if (alarmPopupOpen || !alarmWachtrij.length) return;
  const signal = alarmWachtrij.shift();
  huidigAlarmSignaal = signal;
  alarmPopupOpen = true;
  ALARM_POPUP_ICOON_EL.textContent = EMOJI_PER_CATEGORIE[signal.categorie] ?? '⚠️';
  ALARM_POPUP_TITEL_EL.textContent = signal.titel;
  ALARM_POPUP_SUB_EL.textContent = signal.detail?.land ?? signal.detail?.subtitel ?? signal.detail?.gebied ?? '';
  ALARM_POPUP_EL.classList.remove('verborgen');
}

function sluitAlarmPopup() {
  ALARM_POPUP_EL.classList.add('verborgen');
  alarmPopupOpen = false;
  huidigAlarmSignaal = null;
  toonVolgendeAlarmPopup();
}

ALARM_POPUP_SLUIT_EL.addEventListener('click', sluitAlarmPopup);
ALARM_POPUP_BEKIJK_EL.addEventListener('click', () => {
  const signal = huidigAlarmSignaal;
  sluitAlarmPopup();
  if (signal) centreerOpMelding(signal);
});

async function verversen() {
  try {
    const [signalenRes, statusRes] = await Promise.all([
      fetch('/api/signals').then((r) => r.json()),
      fetch('/api/status').then((r) => r.json()),
    ]);
    ERROR_EL.classList.remove('show');

    const perCategorie = {};
    for (const s of signalenRes.signalen) {
      (perCategorie[s.categorie] ??= []).push(s);
    }

    verwerkTornadoAlarm(signalenRes.signalen);
    renderMap(signalenRes.signalen);
    renderMeldingen(signalenRes.signalen);
    renderSky(perCategorie);
    renderWeer(perCategorie);

    VERBINDING_EL.textContent = 'verbonden';
    BIJGEWERKT_EL.textContent = `Bijgewerkt: ${geledenTekst(Date.now())}`;
  } catch (err) {
    VERBINDING_EL.textContent = 'geen verbinding';
    ERROR_EL.textContent = `Kan de aggregator-service niet bereiken: ${err.message}`;
    ERROR_EL.classList.add('show');
  }
}

async function laadConfig() {
  try {
    THUIS = await fetch('/api/config').then((r) => r.json());
    LOC_NAAM_EL.textContent = THUIS.homeLabel;
    INST_LOCATIE_EL.textContent = `${THUIS.homeLabel} (${THUIS.homeLat.toFixed(4)}, ${THUIS.homeLon.toFixed(4)})`;
  } catch {
    LOC_NAAM_EL.textContent = 'Onbekende locatie';
  }
  initMap();
}

updateKlok();
setInterval(updateKlok, 15000);
laadConfig().then(verversen);
laadRadarstations();
setInterval(verversen, 20000);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}
